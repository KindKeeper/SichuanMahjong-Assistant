"""贝叶斯读牌（T7 实战版，§12.3）：由公开信息推断三家手牌。

输入：自家手牌+副露、三家牌河（按出牌序）、三家副露、三家定缺。
方法：对每家独立做序贯重要性采样（SMC-lite）——
  采样起始手牌（从未见牌池）→ 逐轮补摸 → 用出牌模型评估"观测到该牌河"的似然：
    · 定缺先打：持缺门牌时以 ~0.9 概率打缺门（均匀），0.1 走通用模型；
    · 通用模型：软 max  over 切后向听（τ=0.5）——烂牌先打。
  权重归一后输出边缘信念 b[t]（期望持张数）与最大似然手牌（MAP）。
独立性近似：三家各自从全池采样（忽略互斥占用）——v1 标注的近似，后续可改联合采样。

确定性：同种子同输出。纯 stdlib。
"""
from __future__ import annotations

import math
import random

from .rules.shanten import shanten_normal
from .tiles import TILES_PER_TYPE, Counts

QUE_DISCARD_PROB = 0.9
TAU = 0.5


def build_unseen(
    my_hand: Counts,
    my_melds: list[tuple],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
) -> Counts:
    """未见牌池 = 4 − 我手 − 我副露 − 全部牌河 − 三家副露。"""
    cnt = [TILES_PER_TYPE] * 27
    for t, n in enumerate(my_hand):
        cnt[t] -= n
    for kind, t in my_melds:
        cnt[t] -= 4 if kind in ("gang", "angang") else 3
    for river in rivers:
        for t in river:
            cnt[t] -= 1
    for melds in opp_melds:
        for kind, t in melds:
            cnt[t] -= 4 if kind in ("gang", "angang") else 3
    if any(n < 0 for n in cnt):
        raise ValueError("公开信息冲突：某张牌被超额计算（检查牌河/副露录入）")
    return tuple(cnt)


def _sample(counts: list[int], n: int, rng: random.Random) -> list[int]:
    """按计数无放回抽 n 张（返回 tile 列表）。"""
    pool = counts[:]
    out = []
    left = sum(pool)
    for _ in range(n):
        x = rng.randrange(left)
        a = 0
        for t in range(27):
            a += pool[t]
            if x < a:
                out.append(t)
                pool[t] -= 1
                left -= 1
                break
    return out


def _discard_logprob(hand: list[int], d: int, que: int | None) -> float:
    """出牌模型：定缺先打（0.9），否则按切后向听软 max（τ=0.5）。"""
    held = set(hand)
    if que is not None:
        que_tiles = [t for t in held if que * 9 <= t < (que + 1) * 9]
        if que_tiles:
            return math.log(QUE_DISCARD_PROB / len(que_tiles)) if d in que_tiles else -10.0
    scores = {}
    for t in held:
        h2 = hand.copy()
        h2.remove(t)
        scores[t] = shanten_normal(_counts27(h2))
    m = min(scores.values())
    w = {t: math.exp(-(s - m) / TAU) for t, s in scores.items()}
    z = sum(w.values())
    return math.log(w[d] / z)


def _counts27(tiles: list[int]) -> Counts:
    c = [0] * 27
    for t in tiles:
        c[t] += 1
    return tuple(c)


def infer_opponent(
    river: list[int],
    opp_melds: list[tuple],
    que: int | None,
    unseen: Counts,
    k: int = 800,
    seed: int = 0,
) -> dict:
    """单家推断：边缘信念 b[27]、MAP 手牌、有效样本数。"""
    p = sum(1 for kd, _ in opp_melds if kd == "peng")
    g = sum(1 for kd, _ in opp_melds if kd in ("gang", "angang"))
    n_hand = 13 + g - 3 * p - 4 * g
    rng = random.Random(seed)
    marg = [0.0] * 27
    w_sum = 0.0
    map_w = -1.0
    map_hand: list[int] = []
    neff = 0.0
    w2_sum = 0.0
    for _ in range(k):
        pool = list(unseen)
        start = _sample(pool, n_hand, rng)
        for t in start:
            pool[t] -= 1
        hand = start[:]
        w = 0.0
        ok = True
        for d in river:
            draw = _sample(pool, 1, rng)[0]
            pool[draw] -= 1
            hand.append(draw)
            if d not in hand:
                ok = False
                break
            hand.remove(d)
            w += _discard_logprob(hand + [d], d, que)  # 评估基于打前手牌
        if not ok:
            continue
        w = math.exp(w)
        w_sum += w
        w2_sum += w * w
        c = _counts27(hand)
        for t in range(27):
            marg[t] += w * c[t]
        if w > map_w:
            map_w = w
            map_hand = sorted(hand)
    if w_sum <= 0:
        raise ValueError("无有效样本：牌河与牌池矛盾（录入了不可能的历史）")
    neff = w_sum * w_sum / max(w2_sum, 1e-12)
    return dict(
        marginals=[m / w_sum for m in marg],
        map_hand=map_hand,
        map_weight=map_w / w_sum,
        neff=neff,
        n_samples=k,
    )


def infer_all(
    my_hand: Counts,
    my_melds: list[tuple],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
    ques: list[int | None],
    k: int = 800,
    seed: int = 0,
) -> list[dict]:
    """三家推断（独立近似）。返回与座位对齐的 dict 列表。"""
    unseen = build_unseen(my_hand, my_melds, rivers, opp_melds)
    return [
        infer_opponent(rivers[o], opp_melds[o], ques[o], unseen, k=k, seed=(seed << 2) | o)
        for o in range(3)
    ]


def infer_summary(
    my_hand: Counts,
    my_melds: list[tuple],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
    ques: list[int | None],
    k: int = 600,
    seed: int = 20260920,
) -> dict:
    """读牌汇总（server 与 PWA 共用）：三家边缘信念 top6 + MAP 手牌。"""
    res = infer_all(my_hand, my_melds, rivers, opp_melds, ques, k=k, seed=seed)
    out = []
    for r in res:
        top = sorted(range(27), key=lambda t: -r["marginals"][t])[:6]
        out.append(
            dict(
                marginals=[round(v, 3) for v in r["marginals"]],
                top=[dict(tile=t, exp=round(r["marginals"][t], 2)) for t in top],
                map_hand=r["map_hand"],
                map_weight=round(r["map_weight"], 3),
                neff=round(r["neff"], 1),
            )
        )
    return {"opponents": out}
