"""贝叶斯读牌（T7 实战版，§12.3）：由公开信息推断三家手牌。

输入：自家手牌+副露、三家牌河（按出牌序）、三家副露、三家定缺。
方法：对每家独立做序贯蒙特卡洛（SMC-lite）——
  粒子 = 起始手牌（预留副露来源张）+ 私有补摸池；逐轮补摸后按出牌模型计权，
  ESS 过低即系统重采样，避免长牌河下的序贯退化（朴素 SIS 在 13 张牌河时存活率 ~0）；
    · 定缺先打：持缺门牌时以 ~0.9 概率打缺门（均匀），0.1 走通用模型；
    · 通用模型：软 max  over 切后向听（τ=0.5）——烂牌先打。
  权重归一后输出边缘信念 b[t]（期望持张数）与最大似然手牌（MAP）。
独立性近似：三家各自从全池采样（忽略互斥占用）——v1 标注的近似，后续可改联合采样。

确定性：同种子同输出。纯 stdlib。
"""
from __future__ import annotations

import math
import random

from .rules.shanten import shanten_normal
from .tiles import TILES_PER_TYPE, Counts

QUE_DISCARD_PROB = 0.9
TAU = 0.5
QUE_CLEAR_DISCARDS = 8  # 舍牌达此数即视为已清缺（定缺者先打缺，~2 圈内必清完）


def build_unseen(
    my_hand: Counts,
    my_melds: list[tuple],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
) -> Counts:
    """未见牌池 = 4 − 我手 − 我副露 − 全部牌河 − 三家副露。

    副露张数口径：碰/杠（明杠·加杠）按 3 计——第 4 张来自某家舍牌，
    已在牌河中扣过（河牌与副露不重复计）；暗杠按 4 计（全部来自手牌）。
    """
    cnt = [TILES_PER_TYPE] * 27
    for t, n in enumerate(my_hand):
        cnt[t] -= n
    for kind, t in my_melds:
        cnt[t] -= 4 if kind == "angang" else 3
    for river in rivers:
        for t in river:
            cnt[t] -= 1
    for melds in opp_melds:
        for kind, t in melds:
            cnt[t] -= 4 if kind == "angang" else 3
    if any(n < 0 for n in cnt):
        raise ValueError("公开信息冲突：某张牌被超额计算（检查牌河/副露录入）")
    return tuple(cnt)


def _sample(counts: list[int], n: int, rng: random.Random) -> list[int]:
    """按计数无放回抽 n 张（返回 tile 列表）。"""
    pool = counts[:]
    out = []
    left = sum(pool)
    for _ in range(n):
        x = rng.randrange(left)
        a = 0
        for t in range(27):
            a += pool[t]
            if x < a:
                out.append(t)
                pool[t] -= 1
                left -= 1
                break
    return out


def _discard_logprob(hand: list[int], d: int, que: int | None) -> float:
    """出牌模型：定缺先打（0.9），否则按切后向听软 max（τ=0.5）。"""
    held = set(hand)
    if que is not None:
        que_tiles = [t for t in held if que * 9 <= t < (que + 1) * 9]
        if que_tiles:
            return math.log(QUE_DISCARD_PROB / len(que_tiles)) if d in que_tiles else -10.0
    scores = {}
    for t in held:
        h2 = hand.copy()
        h2.remove(t)
        scores[t] = shanten_normal(_counts27(h2))
    m = min(scores.values())
    w = {t: math.exp(-(s - m) / TAU) for t, s in scores.items()}
    z = sum(w.values())
    return math.log(w[d] / z)


def _counts27(tiles: list[int]) -> Counts:
    c = [0] * 27
    for t in tiles:
        c[t] += 1
    return tuple(c)


def _meld_contrib(melds: list[tuple]) -> list[int]:
    """副露对手牌的提取（碰 2 / 杠 3 / 暗杠 4，按牌展开）——推断末从演化手牌扣除。"""
    out: list[int] = []
    for kind, t in melds:
        out.extend([t] * (4 if kind == "angang" else 3 if kind == "gang" else 2))
    return out


def _resample(parts: list[list], seed: int, gen: int) -> list[list]:
    """系统重采样：ESS < N/2 时按权重重生粒子（权重清零），防止序贯退化。

    粒子格式 [logw, hand, pool, start, rng]。子代按 (seed, gen, i) 重开独立 rng 流——
    否则克隆体共享随机流会永久锁步，一步缺张即确定性全灭。全灭返回 []。
    """
    n = len(parts)
    logs = [pt[0] for pt in parts]
    m = max(logs)
    ws = [0.0 if x == -math.inf else math.exp(x - m) for x in logs]
    tot = sum(ws)
    if tot <= 0:
        return []
    neff = tot * tot / sum(w * w for w in ws)
    if neff >= n / 2:
        return parts
    master = random.Random(f"{seed}:res:{gen}")
    step = tot / n
    u = master.random() * step
    out = []
    idx = 0
    c = ws[0]
    for i in range(n):
        pos = u + i * step
        while pos > c:
            idx += 1
            c += ws[idx]
        src = parts[idx]
        out.append([0.0, src[1][:], src[2][:], src[3][:],
                    random.Random(f"{seed}:{gen}:{i}"), src[5][:]])
    return out


def infer_opponent(
    river: list[int],
    opp_melds: list[tuple],
    que: int | None,
    unseen: Counts,
    k: int = 800,
    seed: int = 0,
    meld_req: list[int] | None = None,
    jiagang_tiles: list[int] | None = None,
) -> dict:
    """单家推断：边缘信念 b[27]、MAP 手牌（当前）、MAP 起始、有效样本数。

    unseen 语义由调用方决定：导出=开局池（4−我初始）；助手=当前池。
    记账（引擎口径）：起始手牌恒 13；碰/大明杠/暗杠各净 −3 张，加杠整回合净 0
    （摸1−杠1+补1−打1）。to_meld = 2·碰 + 3·杠 + 4·暗杠，加杠组经 jiagang_tiles
    按 2 计（第 4 张来自补摸）。无对应舍牌的补摸 = 暗杠 + 加杠（每家杠恰补 1），
    碰后必切不摸（共 p+j 次，缺的位置按"前 p+j 次舍牌"近似）。
    方法：SMC——粒子=起始手牌（预留副露来源张）+私有补摸池+独立随机流，逐轮补摸、
    按出牌模型计权、ESS 过低即系统重采样（子代重开随机流防锁步全灭），避免长牌河
    序贯退化。
    """
    if meld_req is None:
        meld_req = _meld_contrib(opp_melds)
    jiagang_tiles = jiagang_tiles or []
    for t in jiagang_tiles:
        meld_req.remove(t)  # 加杠第 4 张来自补摸：组贡献 3 → 2
    p = sum(1 for kd, _ in opp_melds if kd == "peng")
    a = sum(1 for kd, _ in opp_melds if kd == "angang")
    n_extra = a + len(jiagang_tiles)  # 无对应舍牌的补摸
    need = _counts27(meld_req)
    if any(need[t] > unseen[t] for t in range(27)):
        raise ValueError("无有效样本：副露张数超过牌池（录入了不可能的历史）")
    # 缺门约束（F15 修订）：定缺者的缺门张只流通于"最后一次缺门舍牌"之前——
    # 清完后既不会再摸到（摸到即打出进河），终态也不持有。因此：
    # ① 该索引之后的补摸池剔除缺门；② 长牌河终态硬拒绝仍持缺门的粒子。
    # （旧版"全程剔除"会破坏开局打缺舍牌的相容性 → 粒子全灭，已废弃）
    que_lo = que_hi = None
    que_cutoff = -1  # 最后一次缺门舍牌的 river 下标；无则 -1
    if que is not None:
        que_lo, que_hi = que * 9, (que + 1) * 9
        qs = [i for i, d in enumerate(river) if que_lo <= d < que_hi]
        if qs:
            que_cutoff = qs[-1]
    parts: list[list] = []
    for i in range(k):
        pool = list(unseen)
        for t in meld_req:
            pool[t] -= 1
        prng = random.Random(f"{seed}:init:{i}")  # 每粒子独立流：克隆体不锁步
        rest = _sample(pool, 13 - len(meld_req), prng)
        for t in rest:
            pool[t] -= 1
        start = rest + list(meld_req)
        # [logw, hand, pool, start, rng, draws]：演化手牌 = 起始 − 副露预留
        parts.append([0.0, rest[:], pool, start, prng, []])
    n_skip = p + len(jiagang_tiles)  # 碰后必切不摸（含被加杠升级的碰）
    gen = 0
    for i, d in enumerate(river):
        if i >= n_skip:  # 缺口按"前 n_skip 次舍牌"近似（开局手牌厚，存活率高）
            for pt in parts:
                draw = _sample(pt[2], 1, pt[4])[0]
                pt[2][draw] -= 1
                pt[1].append(draw)
                pt[5].append(draw)
        for pt in parts:
            if d in pt[1]:
                pt[1].remove(d)
                pt[0] += _discard_logprob(pt[1] + [d], d, que)  # 评估基于打前手牌
            else:
                pt[0] = -math.inf
        parts = _resample(parts, seed, gen)
        gen += 1
        if not parts:
            raise ValueError("无有效样本：牌河与牌池矛盾（录入了不可能的历史）"
                             + ("——检查该家定缺是否正确、牌河是否录错" if que is not None else ""))
        if que_lo is not None and i == que_cutoff:  # 此后补摸不含缺门
            for pt in parts:
                for t in range(que_lo, que_hi):
                    pt[2][t] = 0
    for _ in range(n_extra):
        for pt in parts:
            draw = _sample(pt[2], 1, pt[4])[0]
            pt[2][draw] -= 1
            pt[1].append(draw)
            pt[5].append(draw)
    # 加杠第 4 张随补摸离手进副露（重放口径：j 动作 hand−1）——终态手牌须扣除；
    # 位置近似在末尾（真实时点为加杠回合），中序持有分析仅轻微偏差
    for t in jiagang_tiles:
        for pt in parts:
            if t in pt[1]:
                pt[1].remove(t)
    # 终态硬拒绝：长牌河（≥ 清理阈值）后仍持缺门的粒子不符合"打完缺"规律
    if que_lo is not None and len(river) >= QUE_CLEAR_DISCARDS:
        parts = [pt for pt in parts if not any(que_lo <= t < que_hi for t in pt[1])]
        if not parts:
            raise ValueError("无有效样本：缺门约束下无存活粒子——检查该家定缺是否正确、牌河是否录错")
    logs = [pt[0] for pt in parts]
    maxlog = max(logs)
    marg = [0.0] * 27
    w_sum = 0.0
    w2_sum = 0.0
    map_w = -1.0
    map_hand: list[int] = []
    map_start: list[int] = []
    map_draws: list[int] = []
    for logw, hand, _pool, start, _prng, draws in parts:
        w = math.exp(logw - maxlog)
        w_sum += w
        w2_sum += w * w
        c = _counts27(hand)
        for t in range(27):
            marg[t] += w * c[t]
        if w > map_w:
            map_w = w
            map_hand = sorted(hand)
            map_start = sorted(start)
            map_draws = list(draws)
    neff = w_sum * w_sum / max(w2_sum, 1e-12)
    return dict(
        marginals=[m / w_sum for m in marg],
        map_hand=map_hand,
        map_start=map_start,
        map_draws=map_draws,
        map_weight=map_w / w_sum,
        neff=neff,
        n_samples=k,
    )


def infer_all(
    my_hand: Counts,
    my_melds: list[tuple],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
    ques: list[int | None],
    k: int = 800,
    seed: int = 0,
    my_river: list[int] = (),
) -> list[dict]:
    """三家推断（独立近似）。返回与座位对齐的 dict 列表。

    rivers 与 opp_melds 对齐（三家）；my_river（我的牌河）只参与未见池扣减——
    我打出的牌是公开信息，扣掉能收紧信念。
    """
    unseen = build_unseen(
        my_hand, my_melds, [list(my_river)] + list(rivers), opp_melds)
    return [
        infer_opponent(rivers[o], opp_melds[o], ques[o], unseen, k=k, seed=(seed << 2) | o)
        for o in range(3)
    ]


def infer_summary(
    my_hand: Counts,
    my_melds: list[tuple],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
    ques: list[int | None],
    k: int = 600,
    seed: int = 20260920,
    my_river: list[int] = (),
) -> dict:
    """读牌汇总（server 与 PWA 共用）：三家边缘信念 top6 + MAP 手牌 + 危险度。"""
    res = infer_all(my_hand, my_melds, rivers, opp_melds, ques, k=k, seed=seed,
                    my_river=my_river)
    out = []
    for r in res:
        top = sorted(range(27), key=lambda t: -r["marginals"][t])[:6]
        out.append(
            dict(
                marginals=[round(v, 3) for v in r["marginals"]],
                top=[dict(tile=t, exp=round(r["marginals"][t], 2)) for t in top],
                map_hand=r["map_hand"],
                map_weight=round(r["map_weight"], 3),
                neff=round(r["neff"], 1),
            )
        )
    from .defense import danger_scores

    unseen = build_unseen(
        my_hand, my_melds, [list(my_river)] + list(rivers), opp_melds)
    visible = tuple(TILES_PER_TYPE - n for n in unseen)
    danger = danger_scores(res, rivers, opp_melds, ques, visible)
    return {"opponents": out, "danger": danger}
