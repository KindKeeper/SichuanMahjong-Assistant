"""实战分析核心（助手 v0 与 PWA 共用）：analyze(tiles, que, k) → 四计划迷你 EV。

口径：v1.9 引擎（碰杠开、官方累加计分、哑对手）；确定性种子（同输入同输出）。
"""
from __future__ import annotations

import zlib

from .agents.greedy import PLANS, _shanten_with, choose_discard
from .agents.que import choose_que
from .features import extract_features
from .simulator import HUANGZHUANG, playout
from .tiles import TILES_PER_TYPE, counts_of
from .wall import Wall


def analyze(tiles: list[int], que: int | None, k: int) -> dict:
    if not (13 <= len(tiles) <= 14):
        raise ValueError("手牌需 13 或 14 张")
    c = counts_of(tiles)
    if any(v > TILES_PER_TYPE for v in c):
        raise ValueError("同种牌超过 4 张")
    if que is None:
        que = choose_que(c)
    f = extract_features(c)
    rows = []
    for p in PLANS:
        if len(tiles) == 14:
            d = choose_discard(p, c, que, 0)
            c13 = list(c)
            c13[d] -= 1
            c13 = tuple(c13)
        else:
            d = None
            c13 = c
        base = zlib.crc32(bytes(c13) + p.encode())
        ev = 0.0
        wins = 0
        for i in range(k):
            out = playout(p, c13, que, Wall.with_hand(c13, (base << 8) | i))
            ev += out.payment + out.gang_income
            wins += out.mode != HUANGZHUANG
        rows.append(
            dict(
                plan=p,
                ev=ev / k,
                win_rate=wins / k,
                discard=d,
                shanten=_shanten_with(p, c, 0),
            )
        )
    best = max(rows, key=lambda r: r["ev"])
    return dict(
        que=que,
        n_tiles=len(tiles),
        features=dict(n_pairs=f.n_pairs, n_max=f.n_max, s_normal=f.s_normal),
        plans=rows,
        recommend=dict(plan=best["plan"], ev=best["ev"], discard=best["discard"]),
    )
