"""实战分析核心（助手 v0.2 与 PWA 共用）：analyze(tiles, que, k, melds=None)。

v0.2 升级：
- 副露输入：已碰/杠（peng/gang/angang）定下来；手牌数按记账不变量自动适配
  （sum(c)+3·碰+4·杠 == 13+杠数），向听/判定自动带 fixed_melds；
- 14 张（刚摸牌）时给出 **EV 切牌排序**：对推荐计划下每个候选切牌跑迷你 MC，
  按期望分排名（不再只是计划内贪心）。
确定性种子：同输入同输出。
"""
from __future__ import annotations

import zlib

from .agents.greedy import PLANS, _shanten_with, choose_discard, flush_plan_of
from .agents.que import choose_que
from .features import extract_features
from .rules.yaku import is_win_any
from .simulator import HUANGZHUANG, playout
from .tiles import TILES_PER_TYPE, counts_of
from .wall import Wall

MELD_KINDS = ("peng", "gang", "angang")


def _sim_ev(plan, c13, que, melds, base: int, k: int, flush_suit=None) -> tuple[float, float]:
    ev = 0.0
    wins = 0
    for i in range(k):
        out = playout(plan, c13, que, Wall.with_state(c13, melds, (base << 8) | i),
                      initial_melds=melds, flush_suit=flush_suit)
        ev += out.payment + out.gang_income
        wins += out.mode != HUANGZHUANG
    return ev / k, wins / k


def _two_phase_rank(plan, items, mk_state, que, melds, base: int, k: int, flush_suit=None) -> list[dict]:
    """两阶段自适应采样：全部候选粗筛（k/3）→ 前 6 精修（k）。

    同预算比单阶段精度更高（头部候选拿到更多模拟）；同精度比单阶段省 ~45% 模拟。
    种子由 base/阶段偏移/tile 决定 → 完全确定。
    """
    k1 = max(4, k // 3)
    est = []
    for t in items:
        ev, _ = _sim_ev(plan, mk_state(t), que, melds, base + 131 * (t + 1), k1, flush_suit)
        est.append((t, ev))
    est.sort(key=lambda x: -x[1])
    final = []
    for t, _ in est[:6]:
        ev, _ = _sim_ev(plan, mk_state(t), que, melds, base + 917 * (t + 1), k, flush_suit)
        final.append((t, ev))
    final.sort(key=lambda x: -x[1])
    return final


def analyze(tiles: list[int], que: int | None, k: int, melds: list | None = None) -> dict:
    c = counts_of(tiles)
    if any(v > TILES_PER_TYPE for v in c):
        raise ValueError("同种牌超过 4 张")
    melds = [tuple(m) for m in (melds or [])]
    if any(k_ not in MELD_KINDS for k_, _ in melds):
        raise ValueError("副露类型需为 peng/gang/angang")
    if len(melds) > 4:
        raise ValueError("副露不超过 4 组")
    # 张数校验：基准（=13+杠−3碰−4杠）或 +1（刚摸牌）
    p = sum(1 for k_, _ in melds if k_ == "peng")
    g = sum(1 for k_, _ in melds if k_ in ("gang", "angang"))
    idle = 13 + g - 3 * p - 4 * g
    n = sum(c)
    if n == idle + 1:
        is_draw = True
    elif n == idle:
        is_draw = False
    else:
        raise ValueError(f"手牌张数不符：含当前副露应持 {idle} 张（摸牌后 {idle + 1}）")
    n_melds = len(melds)
    if que is None:
        que = choose_que(c)

    f = extract_features(c)
    # 计划可行性：七对门清；清一色需副露同色（异色副露的清一色永不成立，F14）
    flush_ok, fs = flush_plan_of(melds)
    plans = [
        pl for pl in PLANS
        if not (pl == "qidui" and n_melds > 0) and not (pl == "flush" and not flush_ok)
    ]
    plan_rows = []
    for pl in plans:
        pl_fs = fs if pl == "flush" else None
        if is_draw:
            d = choose_discard(pl, c, que, n_melds, pl_fs)
            c13 = list(c)
            c13[d] -= 1
            c13 = tuple(c13)
        else:
            d = None
            c13 = c
        base = zlib.crc32(bytes(c13) + bytes([n_melds]) + pl.encode())
        ev, wr = _sim_ev(pl, c13, que, melds, base, k, pl_fs)
        plan_rows.append(
            dict(plan=pl, ev=ev, win_rate=wr, discard=d,
                 shanten=_shanten_with(pl, c, n_melds, pl_fs))
        )
    best = max(plan_rows, key=lambda r: r["ev"])

    # EV 切牌排序（刚摸牌时，两阶段）：对推荐计划，每个候选切牌
    discard_rank = []
    if is_draw:
        base0 = zlib.crc32(bytes(c) + b"discard" + best["plan"].encode())

        def _after_cut(t):
            c13 = list(c)
            c13[t] -= 1
            return tuple(c13)

        bfs = fs if best["plan"] == "flush" else None
        discard_rank = [
            dict(discard=t, ev=ev)
            for t, ev in _two_phase_rank(best["plan"], [t for t, n in enumerate(c) if n], _after_cut, que, melds, base0, k, bfs)
        ]
        best = dict(best)
        best["discard"] = discard_rank[0]["discard"]
        best["ev"] = discard_rank[0]["ev"]
        # 计划卡与榜/横幅同步：best 行更新为 EV 榜值（原值是计划内贪心态）
        for row in plan_rows:
            if row["plan"] == best["plan"]:
                row["discard"] = best["discard"]
                row["ev"] = best["ev"]

    # 等张榜（13 张待机时）：推荐计划下，能使向听前进（听牌时=成和）的牌——
    # "我在等的牌"。按余张降序（大路优先），附各张摸入后的最优路径 EV 与总进张数。
    draw_rank = []
    wait_total = 0
    if not is_draw:
        bfs = fs if best["plan"] == "flush" else None
        s0 = _shanten_with(best["plan"], c, n_melds, bfs)
        base1 = zlib.crc32(bytes(c) + b"wait" + best["plan"].encode())
        meld_cnt = [0] * 27
        for kind, t in melds:
            meld_cnt[t] += 4 if kind in ("gang", "angang") else 3
        rows = []
        for t in range(27):
            left = TILES_PER_TYPE - c[t] - meld_cnt[t]
            if left <= 0:
                continue
            if que is not None and que * 9 <= t < (que + 1) * 9:
                continue  # 缺门牌必立即打掉（被支配），不在等张之列
            c14 = list(c)
            c14[t] += 1
            c14 = tuple(c14)
            if s0 == 0:
                useful = is_win_any(c14, que, melds)
            else:
                useful = _shanten_with(best["plan"], c14, n_melds, bfs) < s0
            if not useful:
                continue
            d = choose_discard(best["plan"], c14, que, n_melds, bfs)
            c13 = list(c14)
            c13[d] -= 1
            ev, _ = _sim_ev(best["plan"], tuple(c13), que, melds,
                            base1 ^ (509 * (t + 1)), max(4, k // 2), bfs)
            rows.append(dict(draw=t, ev=round(ev, 4), left=left, shanten=s0 - 1))
        rows.sort(key=lambda x: (-x["left"], -x["ev"], x["draw"]))
        draw_rank = rows[:10]
        wait_total = sum(x["left"] for x in rows)

    return dict(
        que=que,
        n_tiles=n,
        is_draw=is_draw,
        melds=[list(m) for m in melds],
        features=dict(n_pairs=f.n_pairs, n_max=f.n_max, s_normal=f.s_normal),
        plans=plan_rows,
        discard_rank=discard_rank[:6],
        draw_rank=draw_rank,
        wait_total=wait_total,
        recommend=dict(plan=best["plan"], ev=best["ev"], discard=best["discard"]),
    )
