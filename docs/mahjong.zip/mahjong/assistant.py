"""实战分析核心（助手 v0.2 与 PWA 共用）：analyze(tiles, que, k, melds=None)。

v0.2 升级：
- 副露输入：已碰/杠（peng/gang/angang）定下来；手牌数按记账不变量自动适配
  （sum(c)+3·碰+4·杠 == 13+杠数），向听/判定自动带 fixed_melds；
- 14 张（刚摸牌）时给出 **EV 切牌排序**：对推荐计划下每个候选切牌跑迷你 MC，
  按期望分排名（不再只是计划内贪心）。
确定性种子：同输入同输出。
"""
from __future__ import annotations

import zlib

from .agents.greedy import PLANS, _shanten_with, choose_discard
from .agents.que import choose_que
from .features import extract_features
from .simulator import HUANGZHUANG, playout
from .tiles import TILES_PER_TYPE, counts_of
from .wall import Wall

MELD_KINDS = ("peng", "gang", "angang")


def _sim_ev(plan, c13, que, melds, base: int, k: int) -> tuple[float, float]:
    ev = 0.0
    wins = 0
    for i in range(k):
        out = playout(plan, c13, que, Wall.with_state(c13, melds, (base << 8) | i), initial_melds=melds)
        ev += out.payment + out.gang_income
        wins += out.mode != HUANGZHUANG
    return ev / k, wins / k


def _two_phase_rank(plan, items, mk_state, que, melds, base: int, k: int) -> list[dict]:
    """两阶段自适应采样：全部候选粗筛（k/3）→ 前 6 精修（k）。

    同预算比单阶段精度更高（头部候选拿到更多模拟）；同精度比单阶段省 ~45% 模拟。
    种子由 base/阶段偏移/tile 决定 → 完全确定。
    """
    k1 = max(4, k // 3)
    est = []
    for t in items:
        ev, _ = _sim_ev(plan, mk_state(t), que, melds, base + 131 * (t + 1), k1)
        est.append((t, ev))
    est.sort(key=lambda x: -x[1])
    final = []
    for t, _ in est[:6]:
        ev, _ = _sim_ev(plan, mk_state(t), que, melds, base + 917 * (t + 1), k)
        final.append((t, ev))
    final.sort(key=lambda x: -x[1])
    return final


def analyze(tiles: list[int], que: int | None, k: int, melds: list | None = None) -> dict:
    c = counts_of(tiles)
    if any(v > TILES_PER_TYPE for v in c):
        raise ValueError("同种牌超过 4 张")
    melds = [tuple(m) for m in (melds or [])]
    if any(k_ not in MELD_KINDS for k_, _ in melds):
        raise ValueError("副露类型需为 peng/gang/angang")
    if len(melds) > 4:
        raise ValueError("副露不超过 4 组")
    # 张数校验：基准（=13+杠−3碰−4杠）或 +1（刚摸牌）
    p = sum(1 for k_, _ in melds if k_ == "peng")
    g = sum(1 for k_, _ in melds if k_ in ("gang", "angang"))
    idle = 13 + g - 3 * p - 4 * g
    n = sum(c)
    if n == idle + 1:
        is_draw = True
    elif n == idle:
        is_draw = False
    else:
        raise ValueError(f"手牌张数不符：含当前副露应持 {idle} 张（摸牌后 {idle + 1}）")
    n_melds = len(melds)
    if que is None:
        que = choose_que(c)

    f = extract_features(c)
    plans = [pl for pl in PLANS if not (pl == "qidui" and n_melds > 0)]  # 七对门清，有副露即不可行
    rows = []
    for pl in plans:
        if is_draw:
            d = choose_discard(pl, c, que, n_melds)
            c13 = list(c)
            c13[d] -= 1
            c13 = tuple(c13)
        else:
            d = None
            c13 = c
        base = zlib.crc32(bytes(c13) + bytes([n_melds]) + pl.encode())
        ev, wr = _sim_ev(pl, c13, que, melds, base, k)
        rows.append(
            dict(plan=pl, ev=ev, win_rate=wr, discard=d, shanten=_shanten_with(pl, c, n_melds))
        )
    best = max(rows, key=lambda r: r["ev"])

    # EV 切牌排序（刚摸牌时，两阶段）：对推荐计划，每个候选切牌
    discard_rank = []
    if is_draw:
        base0 = zlib.crc32(bytes(c) + b"discard" + best["plan"].encode())

        def _after_cut(t):
            c13 = list(c)
            c13[t] -= 1
            return tuple(c13)

        discard_rank = [
            dict(discard=t, ev=ev)
            for t, ev in _two_phase_rank(best["plan"], [t for t, n in enumerate(c) if n], _after_cut, que, melds, base0, k)
        ]
        best = dict(best)
        best["discard"] = discard_rank[0]["discard"]
        best["ev"] = discard_rank[0]["ev"]

    # 摸入期望榜（13 张待机时，两阶段）：推荐计划下，每种可摸牌 → 摸入后最优切牌
    draw_rank = []
    if not is_draw:
        base1 = zlib.crc32(bytes(c) + b"draw" + best["plan"].encode())

        def _after_draw(t):
            c14 = list(c)
            c14[t] += 1
            d = choose_discard(best["plan"], tuple(c14), que, n_melds)
            c14[d] -= 1
            return tuple(c14)

        # 余量 = 4 − 手牌 − 副露占用（碰 3 / 杠 4）；候选只保留余量 ≥1 的牌（副露牌绝不可再摸入）
        meld_cnt = [0] * 27
        for kind, t in melds:
            meld_cnt[t] += 4 if kind in ("gang", "angang") else 3
        items = [t for t in range(27) if TILES_PER_TYPE - c[t] - meld_cnt[t] > 0]
        draw_rank = [
            dict(draw=t, ev=ev, left=TILES_PER_TYPE - c[t] - meld_cnt[t])
            for t, ev in _two_phase_rank(best["plan"], items, _after_draw, que, melds, base1, k)
        ]

    return dict(
        que=que,
        n_tiles=n,
        is_draw=is_draw,
        melds=[list(m) for m in melds],
        features=dict(n_pairs=f.n_pairs, n_max=f.n_max, s_normal=f.s_normal),
        plans=rows,
        discard_rank=discard_rank[:6],
        draw_rank=draw_rank[:8],
        recommend=dict(plan=best["plan"], ev=best["ev"], discard=best["discard"]),
    )
