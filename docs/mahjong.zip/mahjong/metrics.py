"""计时与诊断工具（T17 性能工程前置）。

用法：
- 实验脚本：用 StageTimer 的 stage() 包各阶段（发牌/特征/模拟），结束 print report。
- 引擎热点：simulator/table 内埋 metrics.stage("...")（PROFILE=False 时几乎零开销）。
- 运行 experiments/e9_profile.py 出环节诊断报告（含向听缓存命中率）。
"""
from __future__ import annotations

import os
import time
from collections import defaultdict
from contextlib import contextmanager

# 全局开关：MAHJONG_PROFILE=1 时引擎埋点生效
PROFILE = os.environ.get("MAHJONG_PROFILE", "") == "1"

_timer: dict[str, float] = defaultdict(float)
_counts: dict[str, int] = defaultdict(int)


@contextmanager
def stage(name: str):
    if not PROFILE:
        yield
        return
    t0 = time.perf_counter()
    yield
    _timer[name] += time.perf_counter() - t0
    _counts[name] += 1


def add(name: str, dt: float) -> None:
    if PROFILE:
        _timer[name] += dt
        _counts[name] += 1


def reset() -> None:
    _timer.clear()
    _counts.clear()


def report(top: int = 12) -> str:
    if not _timer:
        return "(profiler off — set MAHJONG_PROFILE=1)"
    lines = ["| 环节 | 总耗时 s | 次数 | 单次 ms |", "|---|---|---|---|"]
    for name, tot in sorted(_timer.items(), key=lambda kv: -kv[1])[:top]:
        n = _counts[name]
        lines.append(f"| {name} | {tot:.2f} | {n} | {tot/n*1000:.3f} |")
    return "\n".join(lines)
