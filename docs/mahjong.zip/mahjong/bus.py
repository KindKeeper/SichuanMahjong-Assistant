"""消息总线（T2，§12.1）——ROS2 式节点通信的进程内实现。

消息 schema：所有模块间通信唯一通道。Message = {type, seq, payload, round}。
topic = type（订阅按消息类型过滤）。v1 为进程内分发；SubprocessTransport 见
sandbox.py（非受信 Agent 的进程隔离，防作弊条款 §12.4 ①）。
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass


@dataclass(frozen=True)
class Message:
    type: str          # Deal/QueDeclare/Draw/Discard/Peng/Gang/Win/WallOut/RoundEnd...
    seq: int           # 全局序号（单调）
    payload: dict      # 类型相关字段
    round: int = 0


class InProcBus:
    """进程内发布/订阅总线。节点 = 订阅回调。"""

    def __init__(self) -> None:
        self._subs: dict[str, list] = defaultdict(list)
        self._all: list = []
        self._seq = 0
        self.log: list[Message] = []

    def publish(self, type_: str, payload: dict, round: int = 0) -> Message:
        self._seq += 1
        msg = Message(type=type_, seq=self._seq, payload=payload, round=round)
        self.log.append(msg)
        for cb in self._subs[type_]:
            cb(msg)
        for cb in self._subs["*"]:
            cb(msg)
        return msg

    def subscribe(self, type_: str, callback) -> None:
        """type_ 为 "*" 订阅全部。"""
        self._subs[type_].append(callback)

    def replay(self) -> list[Message]:
        return list(self.log)
