"""防守评估（T24 v1）：基于读牌信念的危险度 / 听牌估计。

口径（v1，全部可解释、纯规则推导，无学习成分）：
  对每家对手 o：
    · MAP 手牌 + 其副露，枚举"补哪张成和" → 听口集合 W；非空即"疑似听牌"，
      每个听口的危险贡献 = MAP 权重（conf）——MAP 即最可能手牌，conf 即置信；
    · 修正（叠乘）：现物（该张在该家河牌）×0.15；
      筋（t±3 同门见于该家河牌，听口为 t 则 t∓3 为现物筋）×0.6；
      该张 4 张全现（我家手牌 + 全部河 + 全部副露）= 0（物理上不可能再点）；
  聚合三家：d[t] = 1 − Π(1 − d_o[t])。

v1 保守之处（TODO）：不估 1 向听的潜在听口；不对对手和牌打点加权
（危险度 × 期望失分才是完整防守度量）；MAP 单点近似（可用边缘信念的
期望化加权替代）。
"""
from __future__ import annotations

import math

from .rules.yaku import is_win_any
from .tiles import TILES_PER_TYPE, Counts, counts_of

GENBUTSU_FACTOR = 0.15
SUJI_FACTOR = 0.6


def _waits(c: Counts, que: int | None, melds: list[tuple]) -> list[int]:
    """补哪张成和（听口枚举）。"""
    out = []
    for t in range(27):
        if c[t] >= TILES_PER_TYPE:
            continue
        comp = list(c)
        comp[t] += 1
        if is_win_any(tuple(comp), que, melds):
            out.append(t)
    return out


def _suji_ok(t: int, river: set[int]) -> bool:
    """t±3 同门是否见于河牌（筋）。"""
    for u in (t - 3, t + 3):
        if 0 <= u < 27 and u // 9 == t // 9 and u in river:
            return True
    return False


def danger_scores(
    beliefs: list[dict],
    rivers: list[list[int]],
    opp_melds: list[list[tuple]],
    ques: list[int | None],
    visible: Counts,
) -> dict:
    """聚合危险度。beliefs=infer_all 结果；visible=全场已见计数（4−unseen）。

    返回 {"tiles": [27 聚合危险度], "opponents": [{"tenpai","conf","waits"}]}。
    """
    n = len(beliefs)
    per = [[0.0] * 27 for _ in range(n)]
    info = []
    for o in range(n):
        r = beliefs[o]
        hand = list(r.get("map_hand") or [])
        conf = float(r.get("map_weight") or 0.0)
        river = set(rivers[o])
        melds = [tuple(m) for m in opp_melds[o]]
        que = ques[o]
        waits: list[int] = []
        if hand:
            waits = _waits(counts_of(hand), que, melds)
        for t in waits:
            d = conf
            if visible[t] >= TILES_PER_TYPE:
                d = 0.0
            else:
                if t in river:
                    d *= GENBUTSU_FACTOR
                if _suji_ok(t, river):
                    d *= SUJI_FACTOR
            per[o][t] = min(1.0, d)
        info.append(dict(tenpai=bool(waits), conf=round(conf, 3), waits=waits))
    agg = [round(1.0 - math.prod(1.0 - per[o][t] for o in range(n)), 4)
           for t in range(27)] if n else [0.0] * 27
    return {"tiles": agg, "opponents": info}
