"""时序动作记录（V1）：紧凑记录整局，可复现 / 校验 / 分叉。

语法（'|' 分段）：
  头段：E<seed36>            引擎局：牌墙由种子决定（发牌/摸牌隐式重建）
        M<deal52><dealer>    实录局：52 张初始牌（base36 两牌一字，座序 0123 各 13 张）+ 庄家
  定缺段：q<座><花色> ×4（花色 0/1/2）
  动作串（按序）：
    d<座><牌>  打出        p<座><牌>  碰        m<座><牌>  大明杠
    a<座><牌>  暗杠        j<座><牌>  加杠      h<座><牌>  点炮和
    z<座><牌>  自摸和      hz         荒庄
  牌 = base36 的 0-9a-q（值 0..26）；座 = 0-3。
整局典型 ~120 字符。复现 = 逐动作重放：维护手牌/河/副露/墙/分数，
每步用 rules/ 校验（持有校验、成牌判定、官方计分），并产出全状态快照。
"""
from __future__ import annotations

import random
import zlib

from .rules.scoring import score_win
from .rules.yaku import is_win_any
from .tiles import TILES_PER_TYPE, counts_of
from .wall import Wall

BASE36 = "0123456789abcdefghijklmnopqrstuvwxyz"
CHAJIAO_PAY = 1
HUAZHU_PAY = 4

_ACTIONS = {"d": "discard", "p": "peng", "m": "daming", "a": "angang", "j": "jiagang",
            "h": "rong", "z": "zimo"}


def _e36(tiles: list[int]) -> str:
    out = []
    for i in range(0, len(tiles), 2):
        v = tiles[i] * 27 + (tiles[i + 1] if i + 1 < len(tiles) else 26)
        out.append(BASE36[v // 36] + BASE36[v % 36])
    return "".join(out)


def _d36(s: str) -> list[int]:
    tiles = []
    for i in range(0, len(s), 2):
        v = BASE36.index(s[i]) * 36 + BASE36.index(s[i + 1])
        tiles.append(v // 27)
        r = v % 27
        if r != 26 or i + 2 < len(s):
            tiles.append(r)
    return tiles


def export_record(events: list[dict], *, seed: int | None = None,
                  deal52: list[int] | None = None, dealer: int = 0) -> str:
    """table.py 事件流 → 记录串。引擎局给 seed；实录局给 deal52（52 张，座序）。"""
    if (seed is None) == (deal52 is None):
        raise ValueError("seed 与 deal52 二选一")
    head = f"E{BASE36[seed % 36]}{seed // 36:x}" if seed is not None else f"M{_e36(deal52)}{dealer}"
    parts = [head]
    setup, actions = [], []
    for ev in events:
        t = ev["type"]
        if t == "QueDeclare":
            setup.append(f"q{ev['seat']}{ev['que']}")
        elif t == "Discard":
            actions.append(f"d{ev['seat']}{BASE36[ev['tile']]}")
        elif t == "Peng":
            actions.append(f"p{ev['seat']}{BASE36[ev['tile']]}")
        elif t == "Gang":
            verb = {"daming": "m", "angang": "a", "jiagang": "j"}[ev["kind"]]
            actions.append(f"{verb}{ev['seat']}{BASE36[ev['tile']]}")
        elif t == "Win":
            actions.append(f"{'h' if ev['mode'] == 'rong' else 'z'}{ev['seat']}{BASE36[ev['win_tile']]}")
        elif t == "WallOut":
            actions.append("hz")
    parts.append("".join(setup))
    parts.append("".join(actions))
    return "|".join(parts)


class ReplayError(ValueError):
    pass


def replay(record: str, scoring_profile: str = "official2024") -> dict:
    """复现整局：返回全状态快照 + 终局。逐动作校验，非法即 ReplayError。"""
    head, setup, actions, wallseg = (record.split("|") + [""] * 4)[:4]
    if head.startswith("E"):
        # E<seed 低位(1位36进制)><seed 高位(hex)> —— 双段避免大 seed 溢出字符集
        seed = int(head[2:], 16) * 36 + BASE36.index(head[1])
        engine_mode = True
        wall = Wall.shuffled(seed)
        hands = [list(wall.deal()) for _ in range(4)]
        dealer = 0
        wall_order = tuple(wall._tiles[wall._pos : wall._end])  # 初始余墙序列（隐藏信息）
    elif head.startswith("M"):
        engine_mode = False
        dealer = int(head[-1])
        deal52 = _d36(head[1:-1])
        if len(deal52) != 52:
            raise ReplayError("M 段应为 52 张初始牌")
        cnt = [0] * 27
        for t in deal52:
            cnt[t] += 1
        if any(n > TILES_PER_TYPE for n in cnt):
            raise ReplayError("初始牌超 4 张同种")
        if wallseg:
            rest = _d36(wallseg)  # 第 4 段：导出时构造的余墙（摸牌按位回填）
            if len(rest) != 108 - 52:
                raise ReplayError("余墙段应为 56 张")
            rc = [0] * 27
            for t in rest:
                rc[t] += 1
            if any(cnt[t] + rc[t] != TILES_PER_TYPE for t in range(27)):
                raise ReplayError("余墙段与初始牌合计非 108")
        else:
            rest = []
            for t, n in enumerate(cnt):
                rest.extend([t] * (TILES_PER_TYPE - n))
            random.Random(0).shuffle(rest)  # 旧版：固定洗牌（只影响墙序不影响校验）
        wall = Wall(deal52 + rest, pos=52)
        hands = [list(counts_of(deal52[s * 13:(s + 1) * 13])) for s in range(4)]
        wall_order = tuple(wall._tiles[52:])  # 实录局余墙顺序（隐藏信息）
    else:
        raise ReplayError("未知头段")

    ques: list[int | None] = [None] * 4
    i = 0
    while i < len(setup):
        if setup[i] != "q":
            raise ReplayError("定缺段格式错误")
        ques[int(setup[i + 1])] = int(setup[i + 2])
        i += 3

    rivers4: list[list[int]] = [[], [], [], []]
    melds: list[list[tuple]] = [[], [], [], []]
    scores = [0, 0, 0, 0]
    winners: list[int] = []
    snaps = []

    def possession(s: int, act: str = "") -> None:
        p = sum(1 for k, _ in melds[s] if k == "peng")
        g = sum(1 for k, _ in melds[s] if k in ("gang", "angang"))
        # 引擎口径：sum + 3碰 + 4杠 == 13 + 杠数（加杠升级的碰已被 gang 替代，
        # 该槽位 −3 恰为"碰 −3 + 加杠净 0"之和——公式对加杠天然正确）
        if sum(hands[s]) + 3 * p + 4 * g != 13 + g:
            raise ReplayError(f"座 {s} 记账破坏 @ {act}")

    def snapshot(seq: int, action: str, drawn: int | None = None) -> None:
        snaps.append(dict(
            seq=seq, action=action, drawn=drawn,
            hands=[tuple(h) for h in hands],
            rivers=[tuple(r) for r in rivers4],
            melds=[tuple(m) for m in melds],
            scores=tuple(scores), winners=list(winners),
            wall_left=wall.remaining,
        ))

    seq = 0
    active = [0, 1, 2, 3]
    last_discarder: int | None = None
    no_draw_next = [False]  # 碰/杠后的必切不再摸牌
    gang_earned = [0, 0, 0, 0]
    j = 0
    while j < len(actions):
        if actions[j] == "h" and actions[j + 1] == "z":
            # 荒庄结算：查叫 + 查花猪（与 table.py 同口径）
            alive = [x for x in active]
            for s2 in alive:
                p2 = sum(1 for k, _ in melds[s2] if k == "peng")
                g2 = sum(1 for k, _ in melds[s2] if k in ("gang", "angang"))
                if sum(hands[s2]) + 3 * p2 + 4 * g2 != 13 + g2:
                    raise ReplayError(f"座 {s2} 记账破坏 @ hz")
            from .rules.yaku import is_tenpai

            tenpai = {s2: is_tenpai(tuple(hands[s2]), ques[s2]) for s2 in alive}
            huazhu = {
                s2: ques[s2] is not None
                and any(hands[s2][t] for t in range(ques[s2] * 9, (ques[s2] + 1) * 9))
                for s2 in alive
            }
            for s2 in alive:
                if huazhu[s2]:
                    scores[s2] -= gang_earned[s2]  # 退杠：杠租作废
            for s2 in alive:
                for o2 in alive:
                    if s2 != o2 and huazhu[s2] and not huazhu[o2]:
                        scores[s2] -= HUAZHU_PAY
                        scores[o2] += HUAZHU_PAY
            t_seats = [s2 for s2 in alive if tenpai[s2] and not huazhu[s2]]
            n_seats = [s2 for s2 in alive if not tenpai[s2] and not huazhu[s2]]
            for s2 in n_seats:
                for o2 in t_seats:
                    scores[s2] -= CHAJIAO_PAY
                    scores[o2] += CHAJIAO_PAY
            snapshot(seq, "hz")
            seq += 1
            j += 2
            continue
        verb = actions[j]
        if verb not in _ACTIONS:
            raise ReplayError(f"未知动作 {verb}")
        s = int(actions[j + 1])
        tile = BASE36.index(actions[j + 2])
        act = f"{verb}{s}{actions[j + 2]}"
        j += 3
        h = hands[s]
        drawn_this = None
        if verb == "d":
            # 非叫牌回合：先隐式摸 1 张（刚碰/杠后的必切不再摸）
            if not no_draw_next[0]:
                t_draw = wall.draw()
                if t_draw is None:
                    raise ReplayError("墙尽仍记录打出")
                h[t_draw] += 1
                drawn_this = t_draw
            no_draw_next[0] = False
            if h[tile] < 1:
                raise ReplayError(f"座 {s} 无 {tile} 可打")
            h[tile] -= 1
            rivers4[s].append(tile)
            last_discarder = s
        elif verb == "p":
            if h[tile] < 2:
                raise ReplayError(f"座 {s} 碰 {tile} 需手牌 2 张")
            h[tile] -= 2
            melds[s].append(("peng", tile))
            no_draw_next[0] = True
        elif verb == "m":
            if h[tile] < 3:
                raise ReplayError(f"座 {s} 大明杠 {tile} 需 3 张")
            h[tile] -= 3
            melds[s].append(("gang", tile))
            if last_discarder is None:
                raise ReplayError("大明杠前无舍牌")
            scores[last_discarder] -= 2
            scores[s] += 2
            gang_earned[s] += 2
            t_sup = wall.draw_tail()
            if t_sup is None:
                raise ReplayError("墙尽仍记录杠")
            h[t_sup] += 1
            no_draw_next[0] = True
        elif verb == "a":
            # 自回合暗杠：链首先摸本回合头牌；连杠续节用上一手补摸（不再摸）
            if not no_draw_next[0]:
                t0 = wall.draw()
                if t0 is None:
                    raise ReplayError("墙尽仍记录杠")
                h[t0] += 1
                drawn_this = t0
            if h[tile] < 4:
                raise ReplayError(f"座 {s} 暗杠 {tile} 需 4 张")
            h[tile] -= 4
            melds[s].append(("angang", tile))
            for o in [x for x in active if x != s]:
                scores[o] -= 2
                scores[s] += 2
                gang_earned[s] += 2
            t_sup = wall.draw_tail()
            if t_sup is None:
                raise ReplayError("墙尽仍记录杠")
            h[t_sup] += 1
            no_draw_next[0] = True
        elif verb == "j":
            if not no_draw_next[0]:
                t0 = wall.draw()
                if t0 is None:
                    raise ReplayError("墙尽仍记录杠")
                h[t0] += 1
                drawn_this = t0
            if ("peng", tile) not in melds[s] or h[tile] < 1:
                raise ReplayError(f"座 {s} 加杠 {tile} 不成立")
            h[tile] -= 1
            melds[s].remove(("peng", tile))
            melds[s].append(("gang", tile))
            for o in [x for x in active if x != s]:
                scores[o] -= 1
                scores[s] += 1
                gang_earned[s] += 1
            t_sup = wall.draw_tail()
            if t_sup is None:
                raise ReplayError("墙尽仍记录杠")
            h[t_sup] += 1
            no_draw_next[0] = True
        elif verb in ("h", "z"):
            if verb == "z":
                # 杠上花：自摸牌来自岭上补摸；普通自摸来自墙头
                drawn = wall.draw_tail() if no_draw_next[0] else wall.draw()
                no_draw_next[0] = False
                if drawn is None:
                    raise ReplayError("墙尽仍记录自摸")
                if engine_mode and drawn != tile:
                    raise ReplayError(f"自摸牌与种子墙不一致：记录 {tile}，墙 {drawn}")
                h[tile] += 1
                drawn_this = drawn
            comp = list(h)
            if not is_win_any(tuple(comp), ques[s], melds[s]):
                raise ReplayError(f"座 {s} 和牌不成立")
            ws = score_win(tuple(comp), melds[s], ques[s], tile,
                           "rong" if verb == "h" else "zimo", profile=scoring_profile)
            others = [x for x in active if x != s]
            if verb == "z":
                per = 1 + ws.total
                for o in others:
                    scores[o] -= per
                scores[s] += per * len(others)
            else:
                if last_discarder is None:
                    raise ReplayError("点炮和前无舍牌")
                scores[last_discarder] -= ws.total
                scores[s] += ws.total
            winners.append(s)
            active.remove(s)
            snapshot(seq, act, drawn_this)
            seq += 1
            continue
        if verb != "d":
            snapshot(seq, act, drawn_this)
            seq += 1
            continue
        possession(s, act)
        snapshot(seq, act, drawn_this)
        seq += 1

    return dict(
        snapshots=snaps,
        final=dict(scores=scores, winners=winners,
                   hands=[tuple(h) for h in hands],
                   rivers=[tuple(r) for r in rivers4],
                   melds=[tuple(m) for m in melds]),
        ques=ques,
        dealer=dealer,
        wall_order=wall_order,
        record=record,
        crc=zlib.crc32(record.encode()),
    )


def project_perspective(replay: dict, seat: int) -> dict:
    """单座视角投影：每个动作时该座可见的一切（+ 明确的隐藏分区）。

    visible：我家手牌/副露、四家河（按序）、四家副露、定缺、墙余量、分数、
             my_draw（该动作自己摸的牌，仅自家动作给出）——即玩家当时的全部知识。
    hidden：  其他三家手牌（训练/读牌评估的标签）。
    不泄漏：visible 不含任何对手手牌字段；隐藏信息仅在 hidden 分区。
    """
    if not 0 <= seat <= 3:
        raise ValueError("seat 0..3")
    trace = []
    for sn in replay["snapshots"]:
        mine = len(sn["action"]) >= 3 and sn["action"][1].isdigit() and int(sn["action"][1]) == seat
        trace.append(dict(
            seq=sn["seq"], action=sn["action"],
            visible=dict(
                my_hand=sn["hands"][seat],
                my_melds=sn["melds"][seat],
                rivers=tuple(sn["rivers"]),
                melds=tuple(sn["melds"]),
                ques=tuple(replay["ques"]),
                wall_left=sn["wall_left"],
                scores=sn["scores"],
                my_draw=sn["drawn"] if mine else None,
            ),
            hidden=dict(
                opp_hands=tuple(sn["hands"][i] for i in range(4) if i != seat),
            ),
        ))
    return dict(seat=seat, que=replay["ques"][seat], wall_order=replay.get("wall_order"),
                trace=trace, final=replay["final"])


def validate_perspective(proj: dict) -> list[str]:
    """视角健全性：逐动作校验"该座每个动作都能仅凭 visible 信息判定合法"。

    返回违规列表（空 = 完全健全）——这是"单座信息完备"的验收：
    玩家任何决策所需的输入都出现在他的视角里。
    """
    seat = proj["seat"]
    errs = []
    for step in proj["trace"]:
        act = step["action"]
        v = step["visible"]
        if len(act) < 3 or not act[1].isdigit() or int(act[1]) != seat:
            continue  # 只校验自家动作
        verb, tile = act[0], BASE36.index(act[2])
        hand = list(v["my_hand"])
        melds = list(v["my_melds"])
        drawn = v["my_draw"]
        pre = hand[:]
        if drawn is not None:
            pre[drawn] -= 1
        if verb == "d":
            pass  # 快照即回合终点，记账已由 replay 保证；打刚摸的牌天然合法——视角无需可判
        elif verb == "p":
            pre[tile] += 2
            if pre[tile] < 2:
                errs.append(f"seq{step['seq']}: 碰 {tile} 手牌不足 2（视角不可判）")
        elif verb == "m":
            pre[tile] += 3
            if pre[tile] < 3:
                errs.append(f"seq{step['seq']}: 大明杠 {tile} 手牌不足 3（视角不可判）")
        elif verb == "j":
            # 快照是升级后的状态：见到 ("gang",tile) 即本动作由碰升级而来（碰必然先前存在）
            if ("gang", tile) not in melds and ("peng", tile) not in melds:
                errs.append(f"seq{step['seq']}: 加杠 {tile} 无对应碰/杠（视角不可判）")
            # 手牌计数：加杠的通常是刚摸的那张（drawn==tile 时恒合法），余者已由 replay 保证
        elif verb == "a":
            pre[tile] += 4
            if pre[tile] < 4:
                errs.append(f"seq{step['seq']}: 暗杠 {tile} 手牌不足 4（视角不可判）")
        elif verb == "z":
            if drawn != tile:
                errs.append(f"seq{step['seq']}: 自摸牌与动作不一致（视角不可判）")
            if not is_win_any(tuple(hand), proj["que"], melds):
                errs.append(f"seq{step['seq']}: 自摸和牌不成立（视角不可判）")
        elif verb == "h":
            if not any(rv and rv[-1] == tile for rv in v["rivers"]):
                errs.append(f"seq{step['seq']}: 点炮 {tile} 无对应舍牌（视角不可判）")
            comp = list(hand)
            comp[tile] += 1
            if not is_win_any(tuple(comp), proj["que"], melds):
                errs.append(f"seq{step['seq']}: 点炮和牌不成立（视角不可判）")
    return errs


class RecorderSession:
    """实战最小交互记录（P 记录）：只输入你看到的，状态机维护/校验/导出。

    输入动作（全部单点）：
      me_draw / me_discard（我摸/我打）｜opp_discard（某家打出）
      call（碰/明杠/暗杠/加杠，任何座位）｜win（点炮/自摸）｜que（补登记定缺）｜huangzhuang
    维护：我的手牌自动增减、轮转（碰杠跳位）、墙计数、逐动作校验（我的动作严格，
    对手动作宽松——只校验可见性边界）、可碰/可杠/可胡高亮。
    导出：P 语义——我的初始牌精确，对手初始牌由信念引擎 MAP 重建（best-effort 复现）。
    """

    def __init__(self, my_tiles: list[int], my_que: int, dealer: int = 0):
        if len(my_tiles) != 13:
            raise ValueError("开局需自家 13 张")
        c = counts_of(my_tiles)
        if any(n > TILES_PER_TYPE for n in c):
            raise ValueError("同种牌超 4 张")
        self.my0 = sorted(my_tiles)
        self.my_hand = list(c)
        self.ques: list[int | None] = [None] * 4
        self.ques[0] = my_que
        self.dealer = dealer
        self.turn = dealer
        self.active = [0, 1, 2, 3]
        self.rivers: list[list[int]] = [[], [], [], []]
        self.melds: list[list[tuple]] = [[], [], [], []]
        self.wall_left = 56
        self.need_draw = True  # 轮到我时先摸后打
        self.pending: int | None = None  # 碰/杠者待打出的座位
        self.my_draws: list[int] = []  # 自家摸牌序列（导出按位回填牌山用）
        self.letters: list[str] = []
        self.done = False
        self.last_discard: tuple[int, int] | None = None  # (seat, tile)

    # ---- 内部 ----
    def _next_after(self, s: int) -> int:
        i = self.active.index(s)
        return self.active[(i + 1) % len(self.active)]

    def _check_my(self, tile: int, need: int, what: str) -> None:
        if self.my_hand[tile] < need:
            raise ReplayError(f"你手中 {what} {tile} 不足 {need} 张")

    def _kong_tile(self, a: dict) -> int:
        """自家杠的补摸张（引擎：杠后即补摸 1 张，随后必切）。"""
        if "kong" not in a:
            raise ReplayError("记录杠需同时给出补摸张 kong")
        t = int(a["kong"])
        if self._unseen_of(t) < 1:
            raise ReplayError("该补摸张 4 张已全部可见")
        return t

    def suggestions(self) -> dict:
        """基于当前可见状态的可用动作高亮。"""
        out = {}
        if self.done or self.turn != 0:
            return out
        melds0 = self.melds[0]
        if self.need_draw:
            out["can_angang"] = [t for t, n in enumerate(self.my_hand) if n == 4]
            out["can_jiagang"] = [t for t, n in enumerate(self.my_hand)
                                  if n >= 1 and ("peng", t) in melds0]
        else:
            comp = tuple(self.my_hand)
            out["can_zimo"] = is_win_any(comp, self.ques[0], melds0)
            out["can_angang"] = [t for t, n in enumerate(self.my_hand) if n == 4]
            out["can_jiagang"] = [t for t, n in enumerate(self.my_hand)
                                  if n >= 1 and ("peng", t) in melds0]
        if self.last_discard is not None:
            _, t = self.last_discard
            comp = list(self.my_hand)
            comp[t] += 1
            out["can_rong"] = is_win_any(tuple(comp), self.ques[0], self.melds[0])
            out["can_peng"] = self.my_hand[t] >= 2
            out["can_daming"] = self.my_hand[t] >= 3
        else:
            out["can_rong"] = out["can_peng"] = out["can_daming"] = False
        return out

    def state(self) -> dict:
        return dict(
            turn=self.turn, wall_left=self.wall_left, need_draw=self.need_draw,
            my_hand=tuple(self.my_hand), my_melds=tuple(self.melds[0]),
            rivers=tuple(tuple(r) for r in self.rivers),
            melds=tuple(tuple(m) for m in self.melds),
            ques=tuple(self.ques), active=tuple(self.active), done=self.done,
            suggestions=self.suggestions(), record=self.export_draft(),
        )

    def export_draft(self) -> str:
        setup = "".join(
            f"q{s}{q}" for s, q in enumerate(self.ques) if q is not None
        )
        head = f"P{_e36(self.my0)}0"  # P 语义：对手初始牌在导出时由信念补齐
        return "|".join([head, setup, "".join(self.letters)])

    # ---- 动作 ----
    def act(self, a: dict) -> dict:
        if self.done:
            raise ReplayError("本局已结束")
        op = a["op"]
        if op == "que":
            s = int(a["seat"])
            if self.letters or any(self.rivers):
                raise ReplayError("定缺只能在开局登记")
            self.ques[s] = int(a["que"])
            return self.state()
        if op == "me_draw":
            if self.turn != 0 or not self.need_draw:
                raise ReplayError("现在不该你摸牌")
            t = int(a["tile"])
            unseen = self._unseen_of(t)
            if unseen < 1:
                raise ReplayError("该牌 4 张已全部可见")
            self.my_hand[t] += 1
            self.wall_left -= 1
            self.my_draws.append(t)
            self.need_draw = False
            return self.state()
        if op == "me_discard":
            if self.pending == 0:
                pass  # 我的碰/杠后必切：不摸直接打
            elif self.turn == 0 and self.need_draw:
                raise ReplayError("先记录你摸的牌")
            elif self.turn != 0:
                raise ReplayError("现在不该你打牌")
            t = int(a["tile"])
            if self.my_hand[t] < 1:
                raise ReplayError(f"手中无 {t} 可打")
            self.my_hand[t] -= 1
            self.rivers[0].append(t)
            self.letters.append(f"d0{BASE36[t]}")
            self.last_discard = (0, t)
            if self.pending == 0:
                self.pending = None
                self.turn = self._next_after(0)
                self.need_draw = self.turn == 0
            else:
                self._advance_after(0)
            return self.state()
        if op == "opp_discard":
            s = int(a["seat"])
            if s == 0 or s not in self.active:
                raise ReplayError("座位无效")
            post_call = self.pending == s
            if not post_call and self.turn != s:
                raise ReplayError(f"现在该 {self.turn} 号位行动")
            t = int(a["tile"])
            unseen = self._unseen_of(t)
            if unseen < 1:
                raise ReplayError("该牌 4 张已全部可见（录重了？）")
            self.rivers[s].append(t)
            if not post_call:
                self.wall_left -= 1
            self.letters.append(f"d{s}{BASE36[t]}")
            self.last_discard = (s, t)
            if post_call:
                self.pending = None
            self._advance_after(s)
            return self.state()
        if op == "call":
            s = int(a["seat"])
            t = int(a["tile"])
            kind = a["kind"]
            if self.last_discard is None and kind in ("peng", "daming"):
                raise ReplayError("叫牌需针对刚打出的一张")
            if kind in ("peng", "daming"):
                ls, lt = self.last_discard
                if lt != t:
                    raise ReplayError("叫牌对象不是上一张舍牌")
                if s == ls:
                    raise ReplayError("不能吃自己的舍牌")
            if s == 0:
                if kind == "peng":
                    self._check_my(t, 2, "碰")
                    self.my_hand[t] -= 2
                elif kind == "daming":
                    self._check_my(t, 3, "大明杠")
                    self.my_hand[t] -= 3
                    self.wall_left -= 1
                    kt = self._kong_tile(a)
                    self.my_hand[kt] += 1
                    self.my_draws.append(kt)
                elif kind == "angang":
                    self._check_my(t, 4, "暗杠")
                    self.my_hand[t] -= 4
                    self.wall_left -= 1
                    kt = self._kong_tile(a)
                    self.my_hand[kt] += 1
                    self.my_draws.append(kt)
                elif kind == "jiagang":
                    if ("peng", t) not in self.melds[0]:
                        raise ReplayError("无对应碰，不能加杠")
                    self._check_my(t, 1, "加杠")
                    self.my_hand[t] -= 1
                    self.wall_left -= 1
                    kt = self._kong_tile(a)
                    self.my_hand[kt] += 1
                    self.my_draws.append(kt)
                else:
                    raise ReplayError("未知叫牌类型")
            verb = {"peng": "p", "daming": "m", "angang": "a", "jiagang": "j"}[kind]
            if kind == "jiagang":
                self.melds[s] = [m for m in self.melds[s] if m != ("peng", t)] + [("gang", t)]
            else:
                self.melds[s].append((kind if kind != "daming" else "gang", t))
            self.letters.append(f"{verb}{s}{BASE36[t]}")
            self.pending = s  # 叫牌者须先打出一张，轮转随后继续
            self.turn = -1
            return self.state()
        if op == "win":
            s = int(a["seat"])
            t = int(a["tile"])
            mode = a["mode"]
            if s == 0:
                comp = list(self.my_hand)
                comp[t] += 1
                if not is_win_any(tuple(comp), self.ques[0], self.melds[0]):
                    raise ReplayError("你和牌不成立")
                if mode == "rong":
                    if self.last_discard != (None, t) and (self.last_discard is None or self.last_discard[1] != t):
                        raise ReplayError("点炮对象不是上一张舍牌")
                else:
                    if self.need_draw:
                        raise ReplayError("先记录你摸的牌再报自摸")
            self.letters.append(f"{'h' if mode == 'rong' else 'z'}{s}{BASE36[t]}")
            nxt = self._next_after(s)  # 先算轮转（移除前）
            self.active.remove(s)
            self.last_discard = None
            self.pending = None
            if len(self.active) <= 1:
                self.done = True
                self.turn = -1
            else:
                self.turn = nxt if nxt in self.active else self.active[0]
                self.need_draw = self.turn == 0
            return self.state()
        if op == "huangzhuang":
            self.letters.append("hz")
            self.done = True
            self.pending = None
            return self.state()
        raise ReplayError(f"未知操作 {op}")

    def _advance_after(self, s: int) -> None:
        """无叫牌响应：轮转继续（被碰/杠跳过的座位失去该轮——与引擎同语义）。"""
        self.turn = self._next_after(s)
        self.need_draw = self.turn == 0

    def _unseen_of(self, t: int) -> int:
        cnt = TILES_PER_TYPE - self.my_hand[t]
        for r in self.rivers:
            cnt -= r.count(t)
        for ms in self.melds:
            for kind, mt in ms:
                if mt == t:
                    cnt -= 4 if kind in ("gang", "angang") else 3
        cnt -= self.my0.count(t) * 0  # my0 已含于 my_hand 变化中，不重复扣
        return cnt

    def export(self, k_infer: int = 800, seed: int = 0) -> str:
        """P → 完整 M 记录：对手初始牌由信念 MAP 重建，余墙按"各家摸牌序列按位回填"构造。

        第 4 段（余墙 56 张）使重放精确：我家手牌逐张一致，对手按其 MAP 历史演化
        （其出牌必在手）。第 4 段缺失时回放退化为固定洗牌（仅引擎校验用途）。
        """
        from .belief import infer_opponent

        if not self.done:
            raise ReplayError("局未结束，不能导出")
        # 模拟池 = 4 −（我初始 13 + 我全部摸牌）——我见到的精确张全部排除；
        # 牌河不扣：对手河牌正是其流张（样本须能摸到它们才能解释舍牌）。
        from .belief import _meld_contrib

        my_flow = [0] * 27
        for t in self.my0 + self.my_draws:
            my_flow[t] += 1
        pool = [TILES_PER_TYPE - n for n in my_flow]
        # 先为所有家的副露预留必占张（碰2/杠3/暗杠4，加杠按2——第 4 张来自补摸），
        # 再序贯重建：约束强者先占池（副露多/河长的席位优先），后位用剩余池——
        # 独立推断按构造不重叠（TODO：联合采样更优）
        order = sorted((1, 2, 3),
                       key=lambda s: -(len(self.melds[s]) * 2 + len(self.rivers[s])))
        jt_of: dict[int, list[int]] = {}
        for s in (1, 2, 3):
            jt = [BASE36.index(x[2]) for x in self.letters
                  if x[0] == "j" and int(x[1]) == s]
            jt_of[s] = jt
            mr = _meld_contrib(self.melds[s])
            for t in jt:
                mr.remove(t)
            for t in mr:
                pool[t] -= 1
        if any(n < 0 for n in pool):
            raise ReplayError("重建冲突：副露预留超过牌池（录入有重复？）")
        opp_starts: dict[int, list[int]] = {}
        opp_draws: dict[int, list[int]] = {}
        for s in order:
            r = infer_opponent(self.rivers[s], self.melds[s], self.ques[s], tuple(pool),
                               k=k_infer, seed=(seed << 2) | s, jiagang_tiles=jt_of[s])
            opp_starts[s] = r["map_start"]
            opp_draws[s] = r["map_draws"]
            for t in r["map_start"] + r["map_draws"]:
                pool[t] -= 1
        deal52 = self.my0 + opp_starts[1] + opp_starts[2] + opp_starts[3]
        if len(deal52) != 52:
            raise ReplayError("重建失败：手牌数不对")
        wall = self._build_wall(deal52, [opp_draws[1], opp_draws[2], opp_draws[3]])
        setup = "".join(f"q{s}{q}" for s, q in enumerate(self.ques) if q is not None)
        head = f"M{_e36(deal52)}{self.dealer}"
        return "|".join([head, setup, "".join(self.letters), _e36(wall[52:])])

    def _build_wall(self, deal52: list[int], opp_draws: list[list[int]]) -> list[int]:
        """余墙构造：letters 步进推算每个摸牌位（墙头/岭上），把序列按位回填。

        我的摸牌序列精确（导出后我的终态手牌/牌河逐张一致）；对手填 MAP 粒子的
        摸牌序列（其出牌在手持分析下成立，重放亦然）。自摸动作（z）若为杠上花
        （上一动作是杠）则其墙位留给余牌——回放对 z 会额外消耗一张墙牌但不入手。
        """
        wall: list[int | None] = [None] * 108
        for i, t in enumerate(deal52):
            wall[i] = t
        slots: list[list[tuple[int, bool]]] = [[], [], [], []]  # (墙位, 是否吃序列)
        head, tail = 52, 107
        no_draw_next = False
        for x in self.letters:
            if x == "hz":
                break
            verb, s = x[0], int(x[1])
            if verb == "d":
                if not no_draw_next:
                    slots[s].append((head, True))
                    head += 1
                no_draw_next = False
            elif verb == "p":
                no_draw_next = True
            elif verb == "m":
                slots[s].append((tail, True))
                tail -= 1
                no_draw_next = True
            elif verb in "aj":
                if not no_draw_next:
                    slots[s].append((head, True))
                    head += 1
                slots[s].append((tail, True))
                tail -= 1
                no_draw_next = True
            elif verb == "z":
                if no_draw_next:  # 杠上花：z 消耗的墙牌不入手（重放 artifact），不吃序列
                    slots[s].append((tail, False))
                    tail -= 1
                else:  # 普通自摸：墙牌即我记录的摸牌
                    slots[s].append((head, True))
                    head += 1
                no_draw_next = False
            elif verb == "h":
                pass
            else:
                raise ReplayError(f"未知动作 {verb}")
        seqs: list[list[int]] = [self.my_draws] + opp_draws
        for s in range(4):
            eat = [pos for pos, f in slots[s] if f]
            if len(seqs[s]) != len(eat):
                raise ReplayError(
                    f"座 {s} 摸牌数与牌局结构不符（{len(seqs[s])}≠{len(eat)}）")
            it = iter(seqs[s])
            for pos, f in slots[s]:
                if f:
                    wall[pos] = next(it)
        # 余牌（未摸的墙位 + 杠上花 artifact 位）补齐
        have = [0] * 27
        for t in wall:
            if t is not None:
                have[t] += 1
        leftover: list[int] = []
        for t in range(27):
            if have[t] > TILES_PER_TYPE:
                raise ReplayError(f"重建冲突：{t} 超 4 张（独立推断重叠，待联合推断）")
            leftover.extend([t] * (TILES_PER_TYPE - have[t]))
        rng = random.Random(0)
        rng.shuffle(leftover)
        it = iter(leftover)
        for pos in range(head, tail + 1):
            if wall[pos] is None:
                wall[pos] = next(it)
        if any(t is None for t in wall):
            raise ReplayError("重建失败：墙位未填满")
        return [int(t) for t in wall]
