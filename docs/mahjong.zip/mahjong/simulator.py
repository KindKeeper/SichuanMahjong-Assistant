"""v1.8 事件循环：三家持牌（先定缺、优先打缺），我方碰 + 杠（暗杠/大明杠/加杠）。

流程：墙头 3×13 发给三家（持牌）→ 各家定缺 → 余墙 56。
每轮：我摸 1（自摸判定）→ 杠循环（加杠/暗杠，可连杠：每次岭上补摸 1 + 杠上花判定
      + 必切 1）→ 若无杠则常规出牌 → 三家依次摸打：
    其舍牌 → 点炮判定（最优先）→ 大明杠（优先于碰；补摸+杠上花+必切）→ 碰判定 → 碰后必切。
杠补摸从墙尾取（岭上）。墙在任何需要摸牌时取尽 → 荒庄（截尾）。

记账不变量：sum(c) + 3·碰 + 4·杠 == 13 + 杠数 全程 assert。
收入（刮风下雨，R13）：暗杠 +6（三家×2）、大明杠 +2（引杠，点杠者）、加杠 +3（绕杠，三家）。
抢杠/杠上炮：需对手也会杠、会点炮——哑模型下不可达，引擎规则已预留（后续行为模型启用）。
"""
from __future__ import annotations

from dataclasses import dataclass

from .agents.dummy import QueAwareDummy
from .agents.greedy import (
    GANG_INCOME,
    PENG_POLICIES,
    _shanten_with,
    best_flush_suit,
    choose_discard,
    pick_gang,
    should_daming_gang,
)
from .rules.scoring import score_win
from .rules.yaku import is_complete
from .tiles import Counts, Suit, tiles_of
from .wall import Wall

ZIMO = "zimo"
RONG = "rong"
HUANGZHUANG = "huangzhuang"
MODES = (ZIMO, RONG, HUANGZHUANG)

Mel = tuple[str, int]  # ("peng", t) / ("gang", t) 大明杠·加杠 / ("angang", t) 暗杠


@dataclass(frozen=True)
class Outcome:
    rounds: int  # 1..14+；荒庄取截尾值（杠补摸会改变总轮数上界）
    mode: str
    melds: int = 0  # 碰组数
    gangs: int = 0  # 杠组数（含暗杠）
    gang_income: int = 0  # 刮风下雨累计收入（比赛分）
    payment: int = 0  # 和牌支付（官方计分，含加番与自摸加底；10.2.4）


def _check_possession(c: list[int], melds: list[Mel]) -> None:
    p = sum(1 for k, _ in melds if k == "peng")
    g = sum(1 for k, _ in melds if k in ("gang", "angang"))
    assert sum(c) + 3 * p + 4 * g == 13 + g, "possession invariant broken"


def playout(
    plan: str,
    hand: Counts,
    que: Suit | None,
    wall: Wall,
    *,
    opp_policy=None,
    enable_peng: bool = True,
    peng_policy: str = "always",
    flush_lock: bool = False,
    que_call_rule: str = "free",
    enable_gang: bool = True,
    enable_scoring: bool = True,
    scoring_profile: str = "official2024",
    initial_melds: tuple | None = None,
) -> Outcome:
    if sum(hand) < 1:
        raise ValueError("empty hand")
    opp_policy = opp_policy or QueAwareDummy()
    opp_counts = [wall.deal() for _ in range(3)]
    opp_hands = [tiles_of(c) for c in opp_counts]
    opp_ques = [opp_policy.choose_que(c) for c in opp_counts]
    if wall.remaining != 108 - sum(hand) - 39:
        raise ValueError("wall size inconsistent with hand and 3 dealt opponents")

    c = list(hand)
    melds: list[Mel] = list(initial_melds) if initial_melds else []
    flush_suit = best_flush_suit(hand) if (flush_lock and plan == "flush") else None
    must_clear_que = que_call_rule == "clear_first"
    gangs = sum(1 for k, _ in melds if k in ("gang", "angang"))
    income = 0
    _check_possession(c, melds)  # 通用入口：sum(c)+3·碰+4·杠 == 13+杠数

    def _pay(mode: str, comp: Counts, win_tile: int, gang_draw: bool) -> int:
        if not enable_scoring:
            return 0
        sea = wall.remaining == 0
        return score_win(
            comp, melds, que, win_tile, mode, gang_draw=gang_draw, sea_bottom=sea,
            profile=scoring_profile,
        ).payment(mode)

    rnd = 0
    while wall.remaining >= 4:
        rnd += 1
        t = wall.draw()
        if t is None:
            break
        c[t] += 1
        if is_complete(plan, tuple(c), que, len(melds)):
            return Outcome(rnd, ZIMO, len(melds), gangs, income, _pay(ZIMO, tuple(c), t, False))
        # 杠循环（加杠/暗杠，连杠 ≤8 保险丝）：杠链中间只补不打，
        # 补摸的牌可再触发杠；循环结束统一切 1 张。
        for _ in range(8):
            if not enable_gang:
                break
            g = pick_gang(plan, tuple(c), que, melds, t, must_clear_que)
            if g is None:
                break
            kind, x = g
            if kind == "jiagang":
                c[x] -= 1
                melds.remove(("peng", x))
                melds.append(("gang", x))
            else:
                c[x] -= 4
                melds.append(("angang", x))
            gangs += 1
            income += GANG_INCOME[kind]
            t2 = wall.draw_tail()
            if t2 is None:
                return Outcome(rnd, HUANGZHUANG, len(melds), gangs, income)
            c[t2] += 1
            if is_complete(plan, tuple(c), que, len(melds)):
                return Outcome(rnd, ZIMO, len(melds), gangs, income, _pay(ZIMO, tuple(c), t2, True))  # 杠上花
            t = t2
        c[choose_discard(plan, tuple(c), que, len(melds), flush_suit)] -= 1
        _check_possession(c, melds)
        # 关键剪枝：本轮我方手牌固定，向听 >0 ⇒ 任何舍牌都不可能点炮成和（加一张最多改善 1 向听）
        s13 = _shanten_with(plan, tuple(c), len(melds), flush_suit)
        for o in range(3):
            oh = opp_hands[o]
            x = wall.draw()
            if x is None:
                return Outcome(rnd, HUANGZHUANG, len(melds), gangs, income)
            oh.append(x)  # 摸入 → 14
            d = opp_policy.choose_discard(oh, opp_ques[o], x)
            oh.remove(d)  # 打出 → 13
            # 剪枝：向听 >1 ⇒ 物理不可能胡（加一张最多改善 2——备用对子可转正成刻；只跳过胡判定，叫牌照常）
            if s13 <= 1:
                c2 = list(c)
                c2[d] += 1
                if is_complete(plan, tuple(c2), que, len(melds)):
                    return Outcome(rnd, RONG, len(melds), gangs, income, _pay(RONG, tuple(c2), d, False))
            if enable_gang and should_daming_gang(plan, c, d, que, must_clear_que):
                c[d] -= 3
                melds.append(("gang", d))
                gangs += 1
                income += GANG_INCOME["daming"]
                t2 = wall.draw_tail()
                if t2 is None:
                    return Outcome(rnd, HUANGZHUANG, len(melds), gangs, income)
                c[t2] += 1
                if is_complete(plan, tuple(c), que, len(melds)):
                    return Outcome(rnd, ZIMO, len(melds), gangs, income, _pay(ZIMO, tuple(c), t2, True))  # 杠上花
                c[choose_discard(plan, tuple(c), que, len(melds), flush_suit)] -= 1
                _check_possession(c, melds)
                s13 = _shanten_with(plan, tuple(c), len(melds), flush_suit)  # 大明杠后手牌已变，重算剪枝基准
            elif enable_peng and PENG_POLICIES[peng_policy](
                plan, c, d, que, len(melds), flush_suit, must_clear_que
            ):
                c[d] -= 2
                melds.append(("peng", d))
                c[choose_discard(plan, tuple(c), que, len(melds), flush_suit)] -= 1
                _check_possession(c, melds)
                s13 = _shanten_with(plan, tuple(c), len(melds), flush_suit)  # 碰后手牌已变，重算剪枝基准
    return Outcome(rnd, HUANGZHUANG, len(melds), gangs, income)
