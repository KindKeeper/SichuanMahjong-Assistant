"""GreedyAgent（T3/L1 对手 + 座位泛化默认陪练）：向听贪心做牌 + always 碰杠 + 见胡必胡。

Agent 协议（base.py）的首个实现：把 greedy.py 的 plan 策略包装成座位选手。
"""
from __future__ import annotations

from .base import Ctx
from .greedy import (
    _call_blocked,
    best_flush_suit,
    choose_discard,
    should_daming_gang,
    should_peng,
)
from .que import choose_que_fewest
from ..tiles import Counts, Suit, Tile


class GreedyAgent:
    """plan 参数化（默认 normal = L1"追求平胡"）；always 碰杠；见胡必胡。

    flush_lock 时，起手首调时锁定最优花色（F6 已被否决的对照变体，默认关）。
    """

    def __init__(self, plan: str = "normal", flush_lock: bool = False, que_call_rule: str = "free"):
        self.plan = plan
        self.flush_lock = flush_lock
        self.must_clear_que = que_call_rule == "clear_first"
        self._locked_suit: Suit | None = None

    def _flush_suit(self, hand: Counts) -> Suit | None:
        if self.plan == "flush" and self.flush_lock:
            if self._locked_suit is None:
                self._locked_suit = best_flush_suit(hand)
            return self._locked_suit
        return None

    # --- Agent 协议 ---
    def choose_que(self, hand: Counts, ctx: Ctx) -> Suit:
        return choose_que_fewest(hand)

    def choose_discard(self, hand: Counts, ctx: Ctx) -> Tile:
        return choose_discard(
            self.plan, hand, ctx.ques[ctx.seat], len(ctx.melds[ctx.seat]), self._flush_suit(hand)
        )

    def should_zimo(self, hand: Counts, ctx: Ctx) -> bool:
        return True

    def should_rong(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool:
        return True

    def should_peng(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool:
        return should_peng(
            self.plan, hand, tile, ctx.ques[ctx.seat], len(ctx.melds[ctx.seat]),
            self._flush_suit(hand), self.must_clear_que,
        )

    def should_daming_gang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool:
        return should_daming_gang(
            self.plan, hand, tile, ctx.ques[ctx.seat], self.must_clear_que
        )

    def should_angang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool:
        if self.plan == "qidui" or hand[tile] < 4:
            return False
        fs = self._flush_suit(hand)
        if fs is not None and not (fs * 9 <= tile < (fs + 1) * 9):
            return False
        return not _call_blocked(self.plan, hand, tile, ctx.ques[ctx.seat], self.must_clear_que)

    def should_jiagang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool:
        if self.plan == "qidui" or ("peng", tile) not in ctx.melds[ctx.seat] or hand[tile] < 1:
            return False
        fs = self._flush_suit(hand)
        if fs is not None and not (fs * 9 <= tile < (fs + 1) * 9):
            return False
        return not _call_blocked(self.plan, hand, tile, ctx.ques[ctx.seat], self.must_clear_que)

    def should_qiang_gang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool:
        return True
