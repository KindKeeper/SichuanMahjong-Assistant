"""定缺策略（D0 决策）。

choose_que_fewest：基线——张数最少的花色（并列取编号小者）。

choose_que_refill_mc：结构感知（默认）。对每个候选缺门 s，把 s 花色视为死牌移除，
按无放回抽样补齐死牌数 k_s 张（模拟排缺期间的进张），使各选项在手牌张数上可比。

质量分两相计算（确定性，同种子同结果）：
- 相 1：quality(s) = Σ_rep min_plan shanten_plan(c_{-s} + 补齐) —— 张数和手牌数相等可比；
- 相 2（仅当最优与次优的差距 ≤ tol 家）：以该计划的有效进张数 u 细分并列。
计划并列按固定顺序取先；u = 能使向听下降的余牌张数合计。种子由手牌 CRC32 派生。
这是 EV 定缺（对整手牌局 MC）的廉价代理。
"""
from __future__ import annotations

import random
import zlib
from collections.abc import Iterator

from ..rules.shanten import shanten_dazi, shanten_flush, shanten_normal, shanten_qidui
from ..tiles import N_TILE_TYPES, TILES_PER_TYPE, Counts, Suit

_PLANS = ("normal", "dazi", "qidui", "flush")


def _shanten(plan: str, c: Counts) -> int:
    if plan == "qidui":
        return shanten_qidui(c)
    if plan == "normal":
        return shanten_normal(c)
    if plan == "dazi":
        return shanten_dazi(c)
    return min(shanten_flush(c, s) for s in range(3))


def _useful(plan: str, c: Counts, s: int) -> int:
    """有效进张：能使该计划向听下降的余牌张数合计。"""
    total = 0
    for t in range(N_TILE_TYPES):
        if c[t] >= TILES_PER_TYPE:
            continue
        c2 = list(c)
        c2[t] += 1
        if _shanten(plan, tuple(c2)) < s:
            total += TILES_PER_TYPE - c[t]
    return total


def _min_shanten(c: Counts) -> int:
    """四计划最小向听（不算 u；tenpai_mc 追逐专用，避免每步 27 次多余求值）。"""
    return min(
        shanten_normal(c),
        shanten_dazi(c),
        shanten_qidui(c),
        min(shanten_flush(c, s) for s in range(3)),
    )


def _best_plan(c: Counts) -> tuple[int, int]:
    """(最小向听, 最优计划的有效进张)。计划同向听按 _PLANS 顺序取先。"""
    best_s, best_u = 99, 0
    for p in _PLANS:
        s = _shanten(p, c)
        if s < best_s:
            best_s, best_u = s, _useful(p, c, s)
    return best_s, best_u


def _refills(c: Counts, s: Suit, seed: int, reps: int) -> Iterator[Counts]:
    """补齐模拟：c 去掉 s 花色后，无放回抽 k_s 张补齐（确定性流）。"""
    base_remaining = [TILES_PER_TYPE - v for v in c]
    lo, hi = s * 9, (s + 1) * 9
    dead = sum(c[lo:hi])
    rng = random.Random((seed << 2) | s)
    for _ in range(reps):
        c2 = list(c)
        for t in range(lo, hi):
            c2[t] = 0
        rem = base_remaining.copy()
        left = 95
        for _ in range(dead):
            x = rng.randrange(left)
            a = 0
            for t in range(N_TILE_TYPES):
                a += rem[t]
                if x < a:
                    c2[t] += 1
                    rem[t] -= 1
                    left -= 1
                    break
        yield tuple(c2)


def choose_que_fewest(c: Counts) -> Suit:
    return min(range(3), key=lambda s: (sum(c[s * 9 : (s + 1) * 9]), s))


def _draw(rem: list[int], rng: random.Random) -> int:
    x = rng.randrange(sum(rem))
    a = 0
    for t in range(N_TILE_TYPES):
        a += rem[t]
        if x < a:
            rem[t] -= 1
            return t
    raise AssertionError("empty pool")


def _turns_to_tenpai(c: Counts, que: Suit, rng: random.Random, cap: int = 20) -> int:
    """单家模拟听牌轮数：先排缺（摸到缺门牌=该轮无进展），再跟随当前最优计划最小向听贪心。

    只数我方摸牌轮数（每轮固定我摸 1 张，与几人玩无关）。截尾于 cap（仅用于定缺比较）。
    """
    hand = list(c)
    rem = [TILES_PER_TYPE - v for v in c]
    turns = 0
    dead = sum(hand[que * 9 : (que + 1) * 9])
    while dead > 0:
        turns += 1
        t = _draw(rem, rng)
        if que * 9 <= t < (que + 1) * 9:
            continue  # 摸到死牌直接过：手牌死牌数不变，本轮无进展
        hand[t] += 1
        d = max(range(que * 9, (que + 1) * 9), key=lambda x: hand[x])
        hand[d] -= 1
        dead -= 1
    # 做牌阶段：跟随当前最优计划（两遍法：先定计划，再在该计划下选打，避免每步全计划×u 开销）
    while _min_shanten(tuple(hand)) > 0:
        turns += 1
        if turns >= cap:
            return cap
        hand[_draw(rem, rng)] += 1
        plan = min(_PLANS, key=lambda p: (_shanten(p, tuple(hand)), _PLANS.index(p)))
        best_d, best_s = -1, 99
        for d, n in enumerate(hand):
            if not n:
                continue
            hand[d] -= 1
            s = _shanten(plan, tuple(hand))
            hand[d] += 1
            if s < best_s:
                best_s, best_d = s, d
        hand[best_d] -= 1
    return turns


def choose_que_tenpai_mc(c: Counts, reps: int = 24) -> Suit:
    """定缺质量 = E[min(听牌轮数, cap)]：直接度量速度，排缺成本自动入账（v0.6 默认）。

    E2 实验证明：向听代理（refill_mc）因忽略排缺时间而劣于张数最少；
    轮数代理是本框架下 EV 定缺（整手 MC）的最近廉价版。
    """
    seed = zlib.crc32(bytes(c))
    best = None
    for s in range(3):
        dead = sum(c[s * 9 : (s + 1) * 9])
        rng = random.Random((seed << 2) | s)
        acc = 0
        for _ in range(reps):
            acc += _turns_to_tenpai(c, s, rng)
        key = (acc / reps, dead, s)
        if best is None or key < best:
            best = key
    return best[2]


def choose_que_refill_mc(c: Counts, reps: int = 60) -> Suit:
    seed = zlib.crc32(bytes(c))
    sums = []
    for s in range(3):
        acc = 0
        for c2 in _refills(c, s, seed, reps):
            acc += _best_plan(c2)[0]
        sums.append((acc, sum(c[s * 9 : (s + 1) * 9]), s))
    sums.sort()
    best_acc = sums[0][0]
    tol = max(1, reps // 30)
    tied = [x for x in sums if x[0] - best_acc <= tol]
    if len(tied) == 1:
        return sums[0][2]
    best = None
    for _, dead, s in tied:
        usum = 0
        for c2 in _refills(c, s, seed, reps):
            usum += _best_plan(c2)[1]
        key = (-usum, dead, s)
        if best is None or key < best:
            best = key
    return best[2]


# 定案（v0.6，用户拍板：简单高效优先）：默认 fewest。
# refill_mc / tenpai_mc 保留为实验代码，不入默认路径：
# - refill_mc（向听代理）在 E2 对照中全面落败于 fewest——它忽略了排缺本身的时间成本
#   （死牌 k 张 ≈ k 轮排缺是 EV 的一阶代价，向听差是二阶）；
# - tenpai_mc（轮数代理）方向正确但 ~330ms/手，不符合"高效"要求。
# EV 定缺（整手 MC）仍是 M2 的正式路径，届时直接以 EV 为目标，不再用代理指标。
choose_que = choose_que_fewest
