"""v1.5 固定规则选手：最小向听贪心 + 碰决策。

- 定缺：默认结构感知版（refill-MC，见 que.py）；choose_que_fewest 可作基线。
- 出牌：死牌优先打（从大到小）；否则限定计划内最小向听切牌，并列取先遇到者。
  向听函数带 fixed_melds（已碰组数）——碰后剩余目标组数减少。
- 碰（always 策略，selective 变体后补）：七对门清永不碰；手中还有缺门牌时不碰
  （必须先打完缺门）；缺门牌不碰；清一色只碰当前最优花色的牌。
"""
from __future__ import annotations

from ..rules.shanten import shanten_dazi, shanten_flush, shanten_normal, shanten_qidui
from ..tiles import Counts, Suit, Tile

PLANS = ("normal", "dazi", "qidui", "flush")
PLAN_SCORES = {"normal": 1, "dazi": 2, "qidui": 4, "flush": 4}


def _shanten_with(plan: str, c: Counts, melds: int, flush_suit: Suit | None = None) -> int:
    if plan == "qidui":
        return shanten_qidui(c)  # 七对门清；melds>0 时上层保证不会走到
    if plan == "normal":
        return shanten_normal(c, fixed_melds=melds)
    if plan == "dazi":
        return shanten_dazi(c, fixed_melds=melds)
    if plan == "flush":
        if flush_suit is not None:
            return shanten_flush(c, flush_suit, fixed_melds=melds)
        return min(shanten_flush(c, s, fixed_melds=melds) for s in range(3))
    raise ValueError(f"unknown plan: {plan}")


def best_flush_suit(c: Counts) -> Suit:
    """起手锁定花色的选择：当前单色平胡向听最优的花色。"""
    return min(range(3), key=lambda s: shanten_flush(c, s))


def flush_plan_of(melds: list[tuple]) -> tuple[bool, Suit | None]:
    """清一色计划 vs 副露的兼容性：异色副露 → (False, _) 不可行；
    同色（或无副露）→ (True, 锁色|None)。同色时锁色使切牌/向听/rollout 全程不漂移。"""
    suits = {t // 9 for _, t in melds}
    if len(suits) > 1:
        return False, None
    return True, (next(iter(suits)) if suits else None)


def choose_discard(
    plan: str, c: Counts, que: Suit | None, melds: int = 0, flush_suit: Suit | None = None
) -> Tile:
    """14（或碰后等任意张数）选 1 打：死牌优先，否则计划内最小向听。
    flush_suit 给定时，flush 计划锁定该花色（不漂移）。"""
    if plan == "qidui" and melds > 0:
        raise ValueError("qidui is menqing; cannot have melds")
    if que is not None:
        for t in range((que + 1) * 9 - 1, que * 9 - 1, -1):
            if c[t]:
                return t
    best_t, best_s = -1, 99
    c2 = list(c)
    for t, n in enumerate(c):
        if not n:
            continue
        c2[t] -= 1
        s = _shanten_with(plan, tuple(c2), melds, flush_suit)
        c2[t] += 1
        if s < best_s:
            best_s, best_t = s, t
    if best_t < 0:
        raise ValueError("empty hand")
    return best_t


def should_peng(
    plan: str,
    c: Counts,
    tile: Tile,
    que: Suit | None,
    melds: int,
    flush_suit: Suit | None = None,
    must_clear_que: bool = False,
) -> bool:
    """always 碰策略（zuopai E4 口径）。

    规则变体（DESIGN R11）：缺门牌不入副露——两变体同禁（碰了缺门牌则永远不可能
    满足缺一门）。must_clear_que=True 为平台严格变体：打完缺门前禁碰杠；默认 False
    （通用规则：只约束和牌结构与花猪，不约束叫牌时机）。
    """
    if plan == "qidui":
        return False  # 门清
    if melds >= 4 or c[tile] < 2:
        return False
    if que is not None:
        if que * 9 <= tile < (que + 1) * 9:
            return False  # 缺门牌不入副露
        if must_clear_que and any(c[t] for t in range(que * 9, (que + 1) * 9)):
            return False  # 变体：打完缺门前禁碰杠
    if plan == "flush":
        strong = flush_suit if flush_suit is not None else min(
            range(3), key=lambda s: shanten_flush(c, s)
        )
        if not (strong * 9 <= tile < (strong + 1) * 9):
            return False  # 清一色只碰强门
    return True


def should_peng_selective(
    plan: str,
    c: Counts,
    tile: Tile,
    que: Suit | None,
    melds: int,
    flush_suit: Suit | None = None,
    must_clear_que: bool = False,
) -> bool:
    """selective 碰（zuopai E4 变体）：预估碰+切牌后的向听，不优于不叫则放弃。

    注：纯碰层面向听目标归一化（fixed_melds+1）使"碰后不差"几乎恒成立，
    selective 与 always 的差异主要体现在带补摸的杠上（见实验对照）。
    """
    if not should_peng(plan, c, tile, que, melds, flush_suit, must_clear_que):
        return False
    before = _shanten_with(plan, c, melds, flush_suit)
    c2 = list(c)
    c2[tile] -= 2
    after = 99
    for d, n in enumerate(c2):
        if not n:
            continue
        c3 = c2.copy()
        c3[d] -= 1
        after = min(after, _shanten_with(plan, tuple(c3), melds + 1, flush_suit))
    return after <= before


PENG_POLICIES = {"always": should_peng, "selective": should_peng_selective}

GANG_INCOME = {"angang": 6, "daming": 2, "jiagang": 3}  # 刮风下雨：暗杠各家2 / 引杠点杠者2 / 绕杠各家1


def _call_blocked(plan: str, c: Counts, t: Tile, que: Suit | None, must_clear_que: bool) -> bool:
    """叫牌公共约束：缺门牌不入副露；变体要求先打完缺门；清一色只动强门。"""
    if que is not None:
        if que * 9 <= t < (que + 1) * 9:
            return True
        if must_clear_que and any(c[x] for x in range(que * 9, (que + 1) * 9)):
            return True
    if plan == "flush":
        strong = min(range(3), key=lambda s: shanten_flush(c, s))
        if not (strong * 9 <= t < (strong + 1) * 9):
            return True
    return False


def pick_gang(
    plan: str,
    c: Counts,
    que: Suit | None,
    melds: list,
    drawn: Tile,
    must_clear_que: bool = False,
) -> tuple[str, Tile] | None:
    """always 杠策略（自摸后）：加杠优先于暗杠，返回 ("jiagang"/"angang", t) 或 None。

    selective 杠变体待设计（补摸期望的评估方式）——归入 F5 后续，杠接入后重测。
    七对门清永不杠：官方无龙七对，quad 留在手里走"带根 ×2"更值。
    """
    if plan == "qidui":
        return None
    if ("peng", drawn) in melds and c[drawn] >= 1:
        if not _call_blocked(plan, c, drawn, que, must_clear_que):
            return ("jiagang", drawn)
    for t, n in enumerate(c):
        if n == 4 and not _call_blocked(plan, c, t, que, must_clear_que):
            return ("angang", t)
    return None


def should_daming_gang(
    plan: str, c: Counts, tile: Tile, que: Suit | None, must_clear_que: bool = False
) -> bool:
    """always 大明杠（他家舍牌，优先于碰）。"""
    if plan == "qidui" or c[tile] < 3:
        return False
    return not _call_blocked(plan, c, tile, que, must_clear_que)
