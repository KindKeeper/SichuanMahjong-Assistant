"""对手策略（座位级可配置的第一步，完整注册表见 DESIGN §10.1）。

QueAwareDummy（v1.5 默认）：先定缺（张数最少），持 13 张手牌，轮到自己摸 1 打 1——
手中还有缺门牌时优先打缺（从大到小），否则摸啥打啥。不碰不杠不胡。

LegacyDummy：v1 原样的纯哑策略（永远打出刚摸的牌），仅作 A/B 对照。
"""
from __future__ import annotations

from .que import choose_que_fewest
from ..tiles import Suit, Tile


class QueAwareDummy:
    def choose_que(self, c) -> Suit:
        return choose_que_fewest(c)

    def choose_discard(self, hand14: list[Tile], que: Suit, drawn: Tile) -> Tile:
        if que is not None:
            for t in range((que + 1) * 9 - 1, que * 9 - 1, -1):
                if t in hand14:
                    return t
        return drawn


class LegacyDummy:
    def choose_que(self, c) -> Suit:
        return choose_que_fewest(c)

    def choose_discard(self, hand14: list[Tile], que: Suit, drawn: Tile) -> Tile:
        return drawn
