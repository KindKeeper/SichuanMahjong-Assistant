"""EVAgent（T8/L2）：逐决策期望最大化（官方计分口径，迷你 MC rollout）。

与 L1 GreedyAgent 的差异：
- 切牌：计划间小样本粗选 → 推荐计划两阶段精排（assistant 同口径），不再是
  单一 plan 的向听贪心；
- 碰/大明杠/暗杠/加杠：EV(鸣牌后最优路径) vs EV(过) 直接对比，选择性接受
  （T9 selective 杠的正主实现）；
- 和牌：见胡必胡（v1；低价值自摸的拒和是后续维度）。

防偷看契约：决策只依赖 (hand, 公开 Ctx)；rollout 内对手为 QueAwareDummy，
引擎隐藏状态（真实余墙/他家手牌）不经 Ctx 流入。随机性全部来自构造器种子
（受信进程内策略，竞赛走子进程沙箱——见 base.py 信任模型）。
"""
from __future__ import annotations

import zlib

from ..simulator import playout
from ..tiles import Counts, Suit, Tile
from ..wall import Wall
from .greedy import PLANS, choose_discard, flush_plan_of

Mel = tuple[str, int]


def _meld_bytes(melds: list[Mel]) -> bytes:
    out = bytearray()
    for k, t in melds:
        out.append(t)
        out.append(0 if k == "peng" else 1 if k == "gang" else 2)
    return bytes(out)


def _plan_ev(pl: str, c13: Counts, que: Suit | None, melds: list[Mel], base: int,
             k: int, flush_suit: Suit | None = None) -> float:
    """单计划 EV：k 次 playout 的 (和牌支付+杠租) 均值。种子 (base,i) 完全确定。"""
    ev = 0.0
    for i in range(k):
        out = playout(pl, c13, que, Wall.with_state(c13, melds, (base << 8) | i),
                      initial_melds=melds, flush_suit=flush_suit)
        ev += out.payment + out.gang_income
    return ev / k


def _plan_list(melds: list[Mel]) -> list[tuple[str, Suit | None]]:
    """可行计划列表（含锁色）：七对门清；清一色需副露同色（F14）。"""
    ok, fs = flush_plan_of(melds)
    out = []
    for pl in PLANS:
        if pl == "qidui" and melds:
            continue
        if pl == "flush" and not ok:
            continue
        out.append((pl, fs if pl == "flush" else None))
    return out


def _best_plan(c13: Counts, que: Suit | None, melds: list[Mel], base: int, k: int) -> tuple[str, float]:
    """可行计划间取 EV 优。"""
    best_pl, best_ev = "normal", -1e9
    c13 = tuple(c13)
    for pl, fs in _plan_list(melds):
        b = zlib.crc32(bytes(c13) + _meld_bytes(melds) + pl.encode()) ^ base
        ev = _plan_ev(pl, c13, que, melds, b, k, fs)
        if ev > best_ev:
            best_pl, best_ev = pl, ev
    return best_pl, best_ev


class EVAgent:
    """k_plan=计划粗选样本数；k_rank=切牌精排样本数；k_call=叫牌对比样本数。"""

    def __init__(self, k_plan: int = 6, k_rank: int = 20, k_call: int = 8, seed: int = 0):
        self.k_plan = k_plan
        self.k_rank = k_rank
        self.k_call = k_call
        self.seed = seed

    # --- 内部工具 ---
    def _que(self, ctx) -> Suit | None:
        return ctx.ques[ctx.seat]

    def _melds(self, ctx) -> list[Mel]:
        return [tuple(m) for m in ctx.melds[ctx.seat]]

    def _base(self, hand: Counts, ctx, tag: str) -> int:
        return zlib.crc32(bytes(hand) + _meld_bytes(self._melds(ctx)) + tag.encode()) ^ self.seed ^ ctx.turn

    def _ev_after_peng(self, hand, tile, ctx) -> float:
        """碰后路径：11 张里计划内贪心切 1 → 评估态（10 张 + 碰）。"""
        que, melds = self._que(ctx), self._melds(ctx)
        c = list(hand)
        c[tile] -= 2
        melds2 = melds + [("peng", tile)]
        best = -1e9
        for pl, fs in _plan_list(melds2):
            d = choose_discard(pl, tuple(c), que, len(melds2), fs)
            c2 = c.copy()
            c2[d] -= 1
            b = zlib.crc32(bytes(c2) + _meld_bytes(melds2) + pl.encode()) ^ self._base(hand, ctx, "peng")
            best = max(best, _plan_ev(pl, tuple(c2), que, melds2, b, self.k_call, fs))
        return best

    def _ev_call_nodraw(self, hand, tile, kind: str, n_take: int, ctx) -> float:
        """杠类路径（杠补摸在 playout 内自然发生，与真实流程同序）：hand−n_take+杠副露。"""
        que, melds = self._que(ctx), self._melds(ctx)
        c = list(hand)
        c[tile] -= n_take
        melds2 = melds + [(kind, tile)]
        _, ev = _best_plan(tuple(c), que, melds2, self._base(hand, ctx, kind + str(tile)), self.k_call)
        return ev

    # --- Agent 协议 ---
    def choose_que(self, hand: Counts, ctx) -> Suit:
        from .que import choose_que_fewest

        return choose_que_fewest(hand)

    def choose_discard(self, hand: Counts, ctx) -> Tile:
        """14 选 1：缺门死牌优先（严格优势——持缺门牌永不和且花猪赔付，EV 差在
        rollout 噪声内不可辨，必须规则层硬约束）→ 计划粗选 → 推荐计划两阶段精排。"""
        que, melds = self._que(ctx), self._melds(ctx)
        cands = [t for t, n in enumerate(hand) if n]
        if que is not None:
            dead = [t for t in cands if que * 9 <= t < (que + 1) * 9]
            if dead:
                cands = dead
        # 计划粗选：对每个可行计划，计划内贪心切 → 小样本 EV
        base = self._base(hand, ctx, "plan")
        best_pl = None
        best_ev = -1e9
        for pl, fs in _plan_list(melds):
            d = choose_discard(pl, hand, que, len(melds), fs)
            c13 = list(hand)
            c13[d] -= 1
            b = zlib.crc32(bytes(c13) + _meld_bytes(melds) + pl.encode()) ^ base
            ev = _plan_ev(pl, tuple(c13), que, melds, b, self.k_plan, fs)
            if ev > best_ev:
                best_pl, best_ev = pl, ev
        # 两阶段切牌精排（共同随机数：所有候选共享同一组墙种子 → 成对比较降噪）
        bfs = None
        for pl, fs in _plan_list(melds):
            if pl == best_pl:
                bfs = fs
        est = []
        for t in cands:
            c13 = list(hand)
            c13[t] -= 1
            c13 = tuple(c13)
            b = zlib.crc32(bytes(hand) + _meld_bytes(melds) + best_pl.encode()) ^ base
            est.append((t, _plan_ev(best_pl, c13, que, melds, b, max(4, self.k_rank // 3), bfs)))
        est.sort(key=lambda x: -x[1])
        best_t, best_ev2 = est[0][0], -1e9
        b2 = zlib.crc32(bytes(hand) + _meld_bytes(melds) + best_pl.encode() + b"r2") ^ base
        for t, _ in est[:6]:
            c13 = list(hand)
            c13[t] -= 1
            c13 = tuple(c13)
            ev = _plan_ev(best_pl, c13, que, melds, b2, self.k_rank, bfs)
            if ev > best_ev2:
                best_t, best_ev2 = t, ev
        return best_t

    def should_zimo(self, hand: Counts, ctx) -> bool:
        return True

    def should_rong(self, hand: Counts, tile: Tile, ctx) -> bool:
        return True

    def should_peng(self, hand: Counts, tile: Tile, ctx) -> bool:
        que, melds = self._que(ctx), self._melds(ctx)
        if hand[tile] < 2 or len(melds) >= 4:
            return False
        if que is not None and que * 9 <= tile < (que + 1) * 9:
            return False  # 缺门牌不入副露（R11，两变体同禁）
        _, ev_pass = _best_plan(hand, que, melds, self._base(hand, ctx, "pass" + str(tile)), self.k_call)
        return self._ev_after_peng(hand, tile, ctx) > ev_pass

    def should_daming_gang(self, hand: Counts, tile: Tile, ctx) -> bool:
        que, melds = self._que(ctx), self._melds(ctx)
        if hand[tile] < 3 or len(melds) >= 4:
            return False
        if que is not None and que * 9 <= tile < (que + 1) * 9:
            return False
        _, ev_pass = _best_plan(hand, que, melds, self._base(hand, ctx, "pass" + str(tile)), self.k_call)
        return self._ev_call_nodraw(hand, tile, "gang", 3, ctx) > ev_pass

    def should_angang(self, hand: Counts, tile: Tile, ctx) -> bool:
        que, melds = self._que(ctx), self._melds(ctx)
        if hand[tile] < 4 or len(melds) >= 4:
            return False
        if que is not None and que * 9 <= tile < (que + 1) * 9:
            return False
        # 过 = 当前 14 张的最优切牌路径
        base = self._base(hand, ctx, "pass" + str(tile))
        ev_pass = -1e9
        for pl, fs in _plan_list(melds):
            d = choose_discard(pl, hand, que, len(melds), fs)
            c13 = list(hand)
            c13[d] -= 1
            b = zlib.crc32(bytes(c13) + _meld_bytes(melds) + pl.encode()) ^ base
            ev_pass = max(ev_pass, _plan_ev(pl, tuple(c13), que, melds, b, self.k_call, fs))
        return self._ev_call_nodraw(hand, tile, "angang", 4, ctx) > ev_pass

    def should_jiagang(self, hand: Counts, tile: Tile, ctx) -> bool:
        que, melds = self._que(ctx), self._melds(ctx)
        if ("peng", tile) not in melds or hand[tile] < 1 or len(melds) >= 4:
            return False
        if que is not None and que * 9 <= tile < (que + 1) * 9:
            return False
        base = self._base(hand, ctx, "pass" + str(tile))
        ev_pass = -1e9
        for pl, fs in _plan_list(melds):
            d = choose_discard(pl, hand, que, len(melds), fs)
            c13 = list(hand)
            c13[d] -= 1
            b = zlib.crc32(bytes(c13) + _meld_bytes(melds) + pl.encode()) ^ base
            ev_pass = max(ev_pass, _plan_ev(pl, tuple(c13), que, melds, b, self.k_call, fs))
        # 加杠路径：碰 → 杠升级（meld 替换），hand−1
        que2, melds2 = que, [("gang", tile) if m == ("peng", tile) else m for m in melds]
        c = list(hand)
        c[tile] -= 1
        _, ev_jg = _best_plan(tuple(c), que2, melds2, base ^ 777, self.k_call)
        return ev_jg > ev_pass

    def should_qiang_gang(self, hand: Counts, tile: Tile, ctx) -> bool:
        return True
