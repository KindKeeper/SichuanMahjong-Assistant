"""Agent 协议与 Ctx（§8.3 定稿，T5）——座位泛化（T1）的接口基础。

防偷看原则：Agent 只能经由这些方法的参数获得信息。Ctx 只含公开状态
（河/副露/定缺/墙数/分数），绝不包含他家手牌或牌墙序列；需要隐藏信息
的决策（如 EVAgent）在自身内部随机化（§8.3）。

防作弊契约（执行上下文分级，tests/test_cheating_canary.py 实证威胁模型）：
- **受信上下文（进程内）**：本仓库自有策略。进程内共享内存，inspect 遍历
  调用栈即可触达引擎隐藏状态——诚实仅靠约定，适用于研究/自对弈。
- **非受信上下文（竞赛/外部提交）**：必须在子进程沙箱中经消息总线运行（T2
  进程隔离需求），Agent 仅能收到序列化的 (hand, Ctx)，物理上无法触达引擎内存。
- Agent 约定：决策只能是 (hand, Ctx) 的函数；不得 import 引擎内部模块
  （mahjong.table/simulator/wall 等）、不得访问全局随机源（需随机性时在
  构造器自接种子）；违反者由审计条款（DESIGN §12.4）判定。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from ..tiles import Counts, Suit, Tile

Mel = tuple[str, int]  # ("peng"|"gang"|"angang", t)


@dataclass(frozen=True)
class Ctx:
    """公开信息快照（每次决策时由引擎构造）。"""

    seat: int  # 自己家座位号 0..3
    wall_left: int
    discards: tuple[tuple[Tile, ...], ...]  # 4 家舍牌河（按出牌序）
    melds: tuple[tuple[Mel, ...], ...]  # 4 家副露
    ques: tuple[Suit | None, ...]  # 4 家定缺
    scores: tuple[int, ...]  # 4 家当前总分（和牌分+杠租累计）
    turn: int  # 当前轮数
    last_draw: Tile | None = None  # 自己刚摸的牌（自回合决策时）


@runtime_checkable
class Agent(Protocol):
    """选手协议：规则 AI / EV AI / RL / 人类代理共用。"""

    # 开局
    def choose_que(self, hand: Counts, ctx: Ctx) -> Suit: ...

    # 自回合（摸牌后，含杠链结束持 14 张时）
    def choose_discard(self, hand: Counts, ctx: Ctx) -> Tile: ...

    # 响应机会（他家舍牌；优先级由引擎裁定：胡 > 大明杠 > 碰）
    def should_zimo(self, hand: Counts, ctx: Ctx) -> bool: ...
    def should_rong(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool: ...
    def should_peng(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool: ...
    def should_daming_gang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool: ...

    # 自回合杠机会（引擎循环询问；返回 False 即杠链终止）
    def should_angang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool: ...  # 手牌 4 张
    def should_jiagang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool: ...  # 加杠第 4 张

    # 抢杠（他家加杠时；哑对手模型下暂不可达，接口预留）
    def should_qiang_gang(self, hand: Counts, tile: Tile, ctx: Ctx) -> bool: ...


@dataclass
class SeatState:
    """引擎维护的单家内部状态（不暴露给 Agent；Agent 只能看到 Ctx 快照）。"""

    hand: list[int]
    melds: list[Mel]
    que: Suit | None
    river: list[int] = field(default_factory=list)  # 舍牌河（按出牌序）
    score: int = 0
    won: bool = False
    win_round: int = 0
    win_score: int = 0  # 该家和牌支付（含加番、自摸加底）
    gang_income: int = 0  # 刮风下雨累计
    gang_ledger: list = field(default_factory=list)  # [(支付座, 分)]——花猪退杠精确退回（T11）


@dataclass
class HandResult:
    """整局（血战）结果：1~3 家和牌或荒庄。"""

    winners: list[int]  # 和牌座位（按和牌先后）
    win_rounds: list[int]
    wall_out: bool  # 荒庄
    scores: list[int]  # 各家净分（和牌+杠租−赔付，正为得）
    events: list[dict] = field(default_factory=list)  # 消息日志（T2 总线的雏形）
