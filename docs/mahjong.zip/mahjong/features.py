"""起手牌结构特征提取（分析用）。

拆解维度：
- 花色分布：n_max / n_mid / n_min（排序后三花色张数）
- 重复结构：n_pairs（count≥2 牌种数）、n_trips（count≥3）、n_quads（count==4，杠胚）
- 连接结构（每花色内从左到右贪心分类）：n_melds 完整面子（顺/刻）、n_tatsu_conn
  两面/边张搭 (i,i+1)、n_tatsu_gap 坎张搭 (i,i+2)、n_pair_solo 无连接独立对子、
  n_singles 孤张
- 综合指标（裁判级精确）：四计划向听 s_* 与有效牌 u_*（能使向听下降的余牌张数合计）

注意：连接结构是特征级贪心近似（不保证最优切分），只用于分析，不用于任何判定；
判定级数值（向听、有效牌）来自 rules/，精确。
"""
from __future__ import annotations

from dataclasses import dataclass

from .rules.shanten import shanten_dazi, shanten_flush, shanten_normal, shanten_qidui
from .tiles import SUIT_SIZE, TILES_PER_TYPE, Counts, counts_of

PLAN_NAMES = ("normal", "dazi", "qidui", "flush")

FEATURE_NAMES = (
    "n_max", "n_mid", "n_min",
    "n_pairs", "n_trips", "n_quads",
    "n_melds", "n_tatsu_conn", "n_tatsu_edge", "n_tatsu_gap", "n_pair_solo", "n_singles",
    "n_terminals",
    "s_normal", "s_qidui", "s_dazi", "s_flush",
    "u_normal", "u_qidui", "u_dazi", "u_flush",
)


@dataclass(frozen=True)
class HandFeatures:
    n_max: int
    n_mid: int
    n_min: int
    n_pairs: int
    n_trips: int
    n_quads: int
    n_melds: int
    n_tatsu_conn: int
    n_tatsu_edge: int
    n_tatsu_gap: int
    n_pair_solo: int
    n_singles: int
    n_terminals: int
    s_normal: int
    s_qidui: int
    s_dazi: int
    s_flush: int
    u_normal: int
    u_qidui: int
    u_dazi: int
    u_flush: int

    def as_row(self) -> tuple[int, ...]:
        return tuple(getattr(self, name) for name in FEATURE_NAMES)


def _plan_shanten(plan: str, c: Counts) -> int:
    if plan == "normal":
        return shanten_normal(c)
    if plan == "qidui":
        return shanten_qidui(c)
    if plan == "dazi":
        return shanten_dazi(c)
    return min(shanten_flush(c, s) for s in range(3))


def _best_flush_suit(c: Counts) -> int:
    return min(range(3), key=lambda s: shanten_flush(c, s))


def _useful(plan: str, c: Counts, s: int, flush_suit: int | None = None) -> int:
    total = 0
    for t in range(len(c)):
        if c[t] >= TILES_PER_TYPE:
            continue
        c2 = list(c)
        c2[t] += 1
        if plan == "flush":
            better = shanten_flush(tuple(c2), flush_suit) < s
        else:
            better = _plan_shanten(plan, tuple(c2)) < s
        if better:
            total += TILES_PER_TYPE - c[t]
    return total


def _greedy_suit_structure(seg: list[int]) -> tuple[int, int, int, int, int, int]:
    """单花色贪心分类 → (面子, 两面/边张搭, 其中边张搭, 坎张搭, 独立对子, 孤张)。

    边张搭 = 含 1 或 9 的 (i,i+1) 搭（12 / 89），成顺效率低于中张两面。
    """
    seg = list(seg)
    melds = conn = edge = gap = pair_solo = singles = 0
    # 面子：先刻子后顺子，从左到右
    i = 0
    while i < SUIT_SIZE:
        if seg[i] >= 3:
            seg[i] -= 3
            melds += 1
            continue
        if i + 2 < SUIT_SIZE and seg[i] and seg[i + 1] and seg[i + 2]:
            seg[i] -= 1
            seg[i + 1] -= 1
            seg[i + 2] -= 1
            melds += 1
            continue
        i += 1
    # 搭子与孤张
    i = 0
    while i < SUIT_SIZE:
        if seg[i] == 0:
            i += 1
            continue
        if seg[i] >= 2 and (i + 1 >= SUIT_SIZE or not seg[i + 1]) and (
            i + 2 >= SUIT_SIZE or not seg[i + 2]
        ):
            pair_solo += 1
            seg[i] -= 2
            continue
        if i + 1 < SUIT_SIZE and seg[i + 1]:
            conn += 1
            if i == 0 or i == SUIT_SIZE - 2:  # 12 / 89 → 边张
                edge += 1
            seg[i] -= 1
            seg[i + 1] -= 1
            continue
        if i + 2 < SUIT_SIZE and seg[i + 2]:
            gap += 1
            seg[i] -= 1
            seg[i + 2] -= 1
            continue
        singles += seg[i]
        seg[i] = 0
        i += 1
    return melds, conn, edge, gap, pair_solo, singles


def extract_features(c: Counts) -> HandFeatures:
    per_suit = [sum(c[s * SUIT_SIZE : (s + 1) * SUIT_SIZE]) for s in range(3)]
    n_max, n_mid, n_min = sorted(per_suit, reverse=True)
    n_pairs = sum(1 for v in c if v >= 2)
    n_trips = sum(1 for v in c if v >= 3)
    n_quads = sum(1 for v in c if v == 4)
    n_terminals = sum(c[s * SUIT_SIZE] + c[s * SUIT_SIZE + SUIT_SIZE - 1] for s in range(3))
    n_melds = n_conn = n_edge = n_gap = n_pair_solo = n_singles = 0
    for s in range(3):
        m, cn, e, g, ps, sg = _greedy_suit_structure(c[s * SUIT_SIZE : (s + 1) * SUIT_SIZE])
        n_melds += m
        n_conn += cn
        n_edge += e
        n_gap += g
        n_pair_solo += ps
        n_singles += sg
    s_normal = shanten_normal(c)
    s_qidui = shanten_qidui(c)
    s_dazi = shanten_dazi(c)
    fs = _best_flush_suit(c)
    s_flush = shanten_flush(c, fs)
    return HandFeatures(
        n_max=n_max,
        n_mid=n_mid,
        n_min=n_min,
        n_pairs=n_pairs,
        n_trips=n_trips,
        n_quads=n_quads,
        n_melds=n_melds,
        n_tatsu_conn=n_conn,
        n_tatsu_edge=n_edge,
        n_tatsu_gap=n_gap,
        n_pair_solo=n_pair_solo,
        n_singles=n_singles,
        n_terminals=n_terminals,
        s_normal=s_normal,
        s_qidui=s_qidui,
        s_dazi=s_dazi,
        s_flush=s_flush,
        u_normal=_useful("normal", c, s_normal),
        u_qidui=_useful("qidui", c, s_qidui),
        u_dazi=_useful("dazi", c, s_dazi),
        u_flush=_useful("flush", c, s_flush, fs),
    )


def gen_two_suit_hand(rng, strong: int, weak: int, n: int) -> Counts:
    """两门口径手牌生成（与 experiments/e3_structured_hands.py 同款）：强门 n + 弱门 13−n。"""
    strong_tiles = [strong * 9 + r for r in range(9) for _ in range(TILES_PER_TYPE)]
    weak_tiles = [weak * 9 + r for r in range(9) for _ in range(TILES_PER_TYPE)]
    picked = rng.sample(strong_tiles, n) + rng.sample(weak_tiles, 13 - n)
    return counts_of(picked)
