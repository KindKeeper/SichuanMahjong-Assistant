"""血战到底整局引擎（T1）：4 座位全 Agent 驱动 + 多人依次胡 + 一炮多响 + 查叫查花猪。

结算假设（Q12 开放项的暂定口径，官方解释确认后调整，常量见下）：
- 查叫：流局时未听牌存活者赔听牌存活者 CHAJIAO_PAY 分（"查大"细则待定，暂用定额）；
- 花猪：流局仍持缺门牌者赔其他存活者 HUAZHU_PAY 分，且其杠租作废（9.3.4 退杠精神）；
- 一炮多响：同一张舍牌多家可胡，全部成立（9.4）；
- 支付：自摸 =（1+基本分）×未和存活人数，各家各付（1+基本分）；点炮 = 基本分由点炮者付。
和牌者的番种由 scoring 按最终组成判定（与做牌过程无关）。
"""
from __future__ import annotations

from .agents.base import Agent, Ctx, HandResult, SeatState
from .rules.scoring import WinScore, score_win
from .rules.yaku import is_tenpai, is_win_any
from .wall import Wall

CHAJIAO_PAY = 1
HUAZHU_PAY = 4
GANG_CHAIN_CAP = 8


def play_hand(
    agents: list[Agent],
    wall: Wall,
    *,
    start_seat: int = 0,
    enable_scoring: bool = True,
    scoring_profile: str = "official2024",
    bus=None,
) -> HandResult:
    """打一整局血战到底。agents 长度 4；返回 HandResult（含消息日志）。

    bus 给定（InProcBus）时，全部事件同步发布到总线（T2：消息流 = 模块间唯一通道）。
    """
    if len(agents) != 4:
        raise ValueError("need exactly 4 agents")

    hands = wall.deal_table()
    seats = [SeatState(hand=list(h), melds=[], que=None) for h in hands]
    events: list[dict] = []
    last_draws: list[int | None] = [None] * 4
    rnd = 0

    def _emit(ev: dict) -> None:
        events.append(ev)
        if bus is not None:
            bus.publish(ev["type"], ev, round=rnd)

    _emit({"type": "Deal"})

    def ctx_for(s: int) -> Ctx:
        return Ctx(
            seat=s,
            wall_left=wall.remaining,
            discards=tuple(tuple(x.river) for x in seats),
            melds=tuple(tuple(x.melds) for x in seats),
            ques=tuple(x.que for x in seats),
            scores=tuple(x.score for x in seats),
            turn=rnd,
            last_draw=last_draws[s],
        )

    def score_of(s: int, comp, win_tile: int, mode: str, gang_draw: bool) -> WinScore:
        if not enable_scoring:
            return WinScore("normal", 1, ())
        return score_win(
            comp, seats[s].melds, seats[s].que, win_tile, mode,
            gang_draw=gang_draw, sea_bottom=wall.remaining == 0,
            profile=scoring_profile,
        )

    def do_win(winner: int, comp, win_tile: int, mode: str, discarder: int | None,
               gang_draw: bool) -> None:
        ws = score_of(winner, comp, win_tile, mode, gang_draw)
        others = [x for x in active if x != winner]
        if mode == "zimo":
            per = 1 + ws.total
            for o in others:
                seats[o].score -= per
            seats[winner].score += per * len(others)
        else:
            assert discarder is not None
            seats[discarder].score -= ws.total
            seats[winner].score += ws.total
        st = seats[winner]
        st.won = True
        st.win_round = rnd
        st.win_score = (1 + ws.total) * len(others) if mode == "zimo" else ws.total
        winners.append(winner)
        active.remove(winner)
        _emit({
            "type": "Win", "seat": winner, "mode": mode, "fan": ws.describe(),
            "total": ws.total, "round": rnd, "win_tile": win_tile,
        })

    def gang_pay(caller: int, kind: str, discarder: int | None, tile: int) -> None:
        per = {"angang": 2, "daming": 2, "jiagang": 1}[kind]
        if kind == "daming":
            assert discarder is not None
            seats[discarder].score -= per
            seats[caller].score += per
            seats[caller].gang_ledger.append((discarder, per))
        else:
            others = [x for x in active if x != caller]
            for o in others:
                seats[o].score -= per
                seats[caller].gang_ledger.append((o, per))
            seats[caller].score += per * len(others)
        seats[caller].gang_income += per * (1 if kind == "daming" else len(active) - 1)
        _emit({"type": "Gang", "seat": caller, "kind": kind, "tile": tile})

    # ---- 定缺 ----
    for s in range(4):
        seats[s].que = agents[s].choose_que(tuple(seats[s].hand), ctx_for(s))
        _emit({"type": "QueDeclare", "seat": s, "que": seats[s].que})

    active: list[int] = [0, 1, 2, 3]
    winners: list[int] = []
    pos = active.index(start_seat)
    wall_exhausted = False

    def advance(after: int) -> int:
        i = active.index(after)
        return (i + 1) % len(active)

    # ---- 主循环 ----
    while len(active) > 1:
        if wall.remaining < 4:
            wall_exhausted = True
            break
        s = active[pos]
        st = seats[s]
        t = wall.draw()
        if t is None:
            wall_exhausted = True
            break
        rnd += 1
        last_draws[s] = t
        st.hand[t] += 1
        _emit({"type": "Draw", "seat": s})
        comp = tuple(st.hand)

        # 自摸（含杠上花前的直接自摸）
        if is_win_any(comp, st.que, st.melds) and agents[s].should_zimo(comp, ctx_for(s)):
            do_win(s, comp, t, "zimo", None, False)
            pos = min(pos, len(active) - 1)
            continue

        # 杠链（加杠/暗杠；每次补摸，杠上花即胡）
        gang_draw_win = False
        for _ in range(GANG_CHAIN_CAP):
            g = None
            if ("peng", t) in st.melds and st.hand[t] >= 1 and agents[s].should_jiagang(comp, t, ctx_for(s)):
                g = ("jiagang", t)
            else:
                for x, n in enumerate(st.hand):
                    if n == 4 and agents[s].should_angang(tuple(st.hand), x, ctx_for(s)):
                        g = ("angang", x)
                        break
            if g is None:
                break
            kind, x = g
            if kind == "jiagang":
                st.hand[x] -= 1
                st.melds.remove(("peng", x))
                st.melds.append(("gang", x))
            else:
                st.hand[x] -= 4
                st.melds.append(("angang", x))
            gang_pay(s, kind, None, x)
            t2 = wall.draw_tail()
            if t2 is None:
                wall_exhausted = True
                break
            st.hand[t2] += 1
            last_draws[s] = t2
            comp = tuple(st.hand)
            if is_win_any(comp, st.que, st.melds) and agents[s].should_zimo(comp, ctx_for(s)):
                do_win(s, comp, t2, "zimo", None, True)
                gang_draw_win = True
                break
            t = t2
        if gang_draw_win:
            pos = min(pos, len(active) - 1)
            continue
        if wall_exhausted:
            break

        # 必切
        d = agents[s].choose_discard(tuple(st.hand), ctx_for(s))
        st.hand[d] -= 1
        st.river.append(d)
        _emit({"type": "Discard", "seat": s, "tile": d, "round": rnd})

        # 响应：一炮多响（先收集所有胡），再无胡则大明杠，再碰
        responders = [x for x in active if x != s]
        rongers: list[tuple[int, tuple]] = []
        for r in responders:
            comp_r = list(seats[r].hand)
            comp_r[d] += 1
            comp_r = tuple(comp_r)
            if is_win_any(comp_r, seats[r].que, seats[r].melds) and agents[r].should_rong(
                comp_r, d, ctx_for(r)
            ):
                rongers.append((r, comp_r))
        if rongers:
            for r, comp_r in rongers:
                do_win(r, comp_r, d, "rong", s, False)
            pos = (active.index(s) + 1) % len(active)  # 从点炮者的下家继续
            continue

        caller = None
        for r in responders:
            if seats[r].hand[d] >= 3 and agents[r].should_daming_gang(
                tuple(seats[r].hand), d, ctx_for(r)
            ):
                caller = r
                break
        called = False
        if caller is not None:
            stc = seats[caller]
            stc.hand[d] -= 3
            stc.melds.append(("gang", d))
            gang_pay(caller, "daming", s, d)
            t2 = wall.draw_tail()
            if t2 is None:
                wall_exhausted = True
                break
            stc.hand[t2] += 1
            last_draws[caller] = t2
            comp_c = tuple(stc.hand)
            if is_win_any(comp_c, stc.que, stc.melds) and agents[caller].should_zimo(comp_c, ctx_for(caller)):
                do_win(caller, comp_c, t2, "zimo", None, True)
                pos = min(pos, len(active) - 1)
                continue
            d2 = agents[caller].choose_discard(comp_c, ctx_for(caller))
            stc.hand[d2] -= 1
            stc.river.append(d2)
            _emit({"type": "Discard", "seat": caller, "tile": d2, "round": rnd})
            called = True
        else:
            for r in responders:
                if seats[r].hand[d] >= 2 and agents[r].should_peng(
                    tuple(seats[r].hand), d, ctx_for(r)
                ):
                    caller = r
                    break
            if caller is not None:
                stc = seats[caller]
                stc.hand[d] -= 2
                stc.melds.append(("peng", d))
                _emit({"type": "Peng", "seat": caller, "tile": d})
                d2 = agents[caller].choose_discard(tuple(stc.hand), ctx_for(caller))
                stc.hand[d2] -= 1
                stc.river.append(d2)
                _emit({"type": "Discard", "seat": caller, "tile": d2, "round": rnd})
                called = True

        if called:
            pos = advance(caller)
        else:
            pos = (pos + 1) % len(active)

    # ---- 荒庄结算：查叫 + 查花猪 ----
    if wall_exhausted and len(active) > 1:
        tenpai = {s: is_tenpai(tuple(seats[s].hand), seats[s].que) for s in active}
        huazhu = {s: seats[s].que is not None and any(
            seats[s].hand[t] for t in range(seats[s].que * 9, (seats[s].que + 1) * 9)
        ) for s in active}
        for s in active:
            if huazhu[s]:  # 退杠：按台账精确退回各支付者（含已和牌退出者），保持零和
                for payer, amt in seats[s].gang_ledger:
                    seats[s].score -= amt
                    seats[payer].score += amt
                seats[s].gang_income = 0
                seats[s].gang_ledger = []
        for s in active:
            for o in active:
                if s == o:
                    continue
                if huazhu[s] and not huazhu[o]:
                    seats[s].score -= HUAZHU_PAY
                    seats[o].score += HUAZHU_PAY
                elif not huazhu[s] and huazhu[o]:
                    pass  # 已由上项对转
        t_seats = [s for s in active if tenpai[s] and not huazhu[s]]
        n_seats = [s for s in active if not tenpai[s] and not huazhu[s]]
        for s in n_seats:
            for o in t_seats:
                seats[s].score -= CHAJIAO_PAY
                seats[o].score += CHAJIAO_PAY
        _emit({
            "type": "WallOut", "tenpai": sorted(t_seats), "huazhu": sorted(huazhu),
        })

    return HandResult(
        winners=winners,
        win_rounds=[seats[w].win_round for w in winners],
        wall_out=wall_exhausted and len(winners) < 3 and len(active) > 1,
        scores=[x.score for x in seats],
        events=events,
    )
