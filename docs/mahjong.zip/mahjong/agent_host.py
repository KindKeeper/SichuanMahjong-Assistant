"""子进程 Agent 宿主（T2，防作弊条款 §12.4 ①）：非受信策略的隔离执行。

协议：stdin/stdout JSON 行。
请求：{"method": "choose_que|choose_discard|should_zimo|...", "hand": [27], "ctx": {...}, "tile": int|null}
响应：{"result": int | bool}
启动：python -m mahjong.agent_host module:Class [key=value ...]
Agent 在子进程内实例化，只能看到反序列化后的 (hand, Ctx)——物理上无法触达引擎内存。
"""
from __future__ import annotations

import importlib
import json
import sys

from .agents.base import Ctx


def _ctx_from(d: dict) -> Ctx:
    return Ctx(
        seat=d["seat"],
        wall_left=d["wall_left"],
        discards=tuple(tuple(x) for x in d["discards"]),
        melds=tuple(tuple(tuple(m) for m in x) for x in d["melds"]),
        ques=tuple(d["ques"]),
        scores=tuple(d["scores"]),
        turn=d["turn"],
        last_draw=d.get("last_draw"),
    )


def _load(target: str, kwargs: dict):
    mod_name, cls_name = target.split(":")
    cls = getattr(importlib.import_module(mod_name), cls_name)
    return cls(**kwargs)


def main() -> None:
    target = sys.argv[1]
    kwargs = {}
    for kv in sys.argv[2:]:
        k, v = kv.split("=", 1)
        kwargs[k] = json.loads(v)
    agent = _load(target, kwargs)
    for line in sys.stdin:
        req = json.loads(line)
        ctx = _ctx_from(req["ctx"])
        hand = tuple(req["hand"])
        tile = req.get("tile")
        method = getattr(agent, req["method"])
        if req["method"] in ("choose_que", "choose_discard", "should_zimo"):
            result = method(hand, ctx)
        else:
            result = method(hand, tile, ctx)
        sys.stdout.write(json.dumps({"result": result}) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
