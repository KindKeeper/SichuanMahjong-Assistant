"""发牌机：固定种子洗牌、发牌、依次摸牌。

同一构造参数 ⇒ 牌序逐位相同（测试强制）。杠补摸在 v1.5 起与摸牌共用 draw()。
"""
from __future__ import annotations

import random

from .tiles import Counts, N_TILE_TYPES, TILES_PER_TYPE, Tile, counts_of, tiles_of


class Wall:
    def __init__(self, tiles: list[Tile], pos: int = 0):
        self._tiles = list(tiles)
        self._pos = pos
        self._end = len(tiles)  # 墙尾指针：杠补摸（岭上）从这里取

    @classmethod
    def shuffled(cls, seed: int) -> "Wall":
        """整副 108 张洗牌，墙头待发。"""
        tiles = list(range(N_TILE_TYPES)) * TILES_PER_TYPE
        random.Random(seed).shuffle(tiles)
        return cls(tiles)

    @classmethod
    def fresh_with_hand(cls, hand: Counts, seed: int) -> "Wall":
        """牌山含给定手牌在墙头（将由 deal_table 发出为 0 号座位）+ 其余洗牌。

        整局引擎（table.play_hand）用；与 with_hand（研究用单人模拟，pos=13）区别在开牌位置。
        """
        if sum(hand) != 13:
            raise ValueError("fresh_with_hand expects a 13-tile hand")
        rest: list[Tile] = []
        for t, n in enumerate(hand):
            rest.extend([t] * (TILES_PER_TYPE - n))
        random.Random(seed).shuffle(rest)
        return cls(tiles_of(hand) + rest, pos=0)

    @classmethod
    def with_hand(cls, hand: Counts, seed: int) -> "Wall":
        """墙 = 给定手牌（视为已从墙头发出）+ 其余按种子洗牌。

        配对实验专用。统计等价性：固定起手 ⇔ 对均匀发牌做条件化，余牌仍均匀随机。
        支持任意张数（含副露后的 10/7/4 张）；杠补摸从墙尾取（岭上）。
        调用方负责再发三家（各 13 张）；余墙 = 108 − len(hand) − 39。
        """
        if sum(hand) < 1:
            raise ValueError("with_hand expects a non-empty hand")
        rest: list[Tile] = []
        for t, n in enumerate(hand):
            rest.extend([t] * (TILES_PER_TYPE - n))
        random.Random(seed).shuffle(rest)
        return cls(tiles_of(hand) + rest, pos=sum(hand))

    @property
    def remaining(self) -> int:
        return self._end - self._pos

    def deal(self, n: int = 13) -> Counts:
        """从墙头取 n 张为一手（起手发牌用）。"""
        return counts_of(self._take(n))

    def deal_table(self) -> list[Counts]:
        """整桌发牌：四家各 13 张，余墙恰 56 张。

        闲家口径（当前模拟器）：庄家第 14 张由其首轮自摸代替。
        接入庄家分支/换三张后改为 14+13×3=53 张、余 55（见 DESIGN §7）。
        """
        hands = [self.deal() for _ in range(4)]
        assert self.remaining == 56, "table deal must leave exactly 56"
        return hands

    def draw(self) -> Tile | None:
        """摸 1 张（墙头）；墙尽返回 None。"""
        if self.remaining == 0:
            return None
        return self._take(1)[0]

    def draw_tail(self) -> Tile | None:
        """岭上补摸：从墙尾取 1 张；取尽返回 None。"""
        if self.remaining == 0:
            return None
        self._end -= 1
        return self._tiles[self._end]

    def _take(self, n: int) -> list[Tile]:
        if self._pos + n > self._end:
            raise ValueError(f"wall underflow: need {n}, remaining {self.remaining}")
        xs = self._tiles[self._pos : self._pos + n]
        self._pos += n
        return xs
