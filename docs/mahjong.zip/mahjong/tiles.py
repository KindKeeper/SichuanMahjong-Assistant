"""牌的编码与计数表示。

编码：tile = suit * 9 + (rank - 1)，suit: 0=条 1=饼 2=万，rank: 1..9，共 27 种、108 张。
一手牌 = 长度 27 的计数元组（不可变、可哈希，可直接作 lru_cache 键）。
"""
from __future__ import annotations

from collections.abc import Iterable

N_SUITS = 3
SUIT_SIZE = 9
N_TILE_TYPES = N_SUITS * SUIT_SIZE            # 27
TILES_PER_TYPE = 4
N_TILES = N_TILE_TYPES * TILES_PER_TYPE       # 108

SUITS = ("条", "饼", "万")
RANK_CHARS = ("一", "二", "三", "四", "五", "六", "七", "八", "九")

Tile = int            # 0..26
Suit = int            # 0..2
Counts = tuple[int, ...]  # len == N_TILE_TYPES


def tile(suit: Suit, rank: int) -> Tile:
    if not (0 <= suit < N_SUITS and 1 <= rank <= SUIT_SIZE):
        raise ValueError(f"invalid tile: suit={suit} rank={rank}")
    return suit * SUIT_SIZE + rank - 1


def suit_of(t: Tile) -> Suit:
    return t // SUIT_SIZE


def rank_of(t: Tile) -> int:
    return t % SUIT_SIZE + 1


def tile_name(t: Tile) -> str:
    return SUITS[suit_of(t)] + RANK_CHARS[rank_of(t) - 1]


def counts_of(tiles: Iterable[Tile]) -> Counts:
    c = [0] * N_TILE_TYPES
    for t in tiles:
        if not (0 <= t < N_TILE_TYPES):
            raise ValueError(f"invalid tile: {t}")
        c[t] += 1
    return tuple(c)


def tiles_of(c: Counts) -> list[Tile]:
    return [t for t, n in enumerate(c) for _ in range(n)]


def is_counts(c: Counts) -> bool:
    return (
        len(c) == N_TILE_TYPES
        and all(isinstance(n, int) and 0 <= n <= TILES_PER_TYPE for n in c)
    )


def hand_str(c: Counts) -> str:
    parts = []
    for s in range(N_SUITS):
        ranks = "".join(
            str(rank_of(t)) * c[t]
            for t in range(s * SUIT_SIZE, (s + 1) * SUIT_SIZE)
            if c[t]
        )
        if ranks:
            parts.append(f"{SUITS[s]}{ranks}")
    return " ".join(parts)
