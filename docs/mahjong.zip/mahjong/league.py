"""联赛框架（T4，§12.4）：策略 round-robin，座位轮换，零和积分排名。

用法：
    from mahjong.league import round_robin
    from mahjong.agents.seat_agents import GreedyAgent
    standings = round_robin({
        "greedy": lambda: GreedyAgent(),
        "qidui": lambda: GreedyAgent(plan="qidui"),
    }, n_hands=40, seed=20260915)
确定性：同种子逐位复现。评分：两家各坐南北/东西各半（座位轮换消位置偏差）。
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from .agents.base import Agent
from .table import play_hand
from .wall import Wall


@dataclass(frozen=True)
class Standing:
    name: str
    score: int        # 联赛总净分（零和：全体 sum = 0）
    hands: int        # 参与对局数


def round_robin(
    agents: dict[str, Agent | object],
    n_hands: int,
    seed: int,
) -> list[Standing]:
    """agents: {名字: Agent 实例工厂（callable）或实例}。返回排名表（按净分降序）。"""
    names = list(agents)

    def make(x):
        # 类（如 GreedyAgent）或无 choose_que 的工厂（lambda）→ 实例化；已是实例 → 原样
        if isinstance(x, type) or not hasattr(x, "choose_que"):
            return x()
        return x

    totals = {n: 0 for n in names}
    hands_played = {n: 0 for n in names}
    rng = random.Random(seed)
    for i, a in enumerate(names):
        for b in names[i + 1 :]:
            for h in range(n_hands):
                wall = Wall.shuffled(rng.randrange(2**31))
                if h % 2 == 0:
                    seats = [make(agents[a]), make(agents[b]), make(agents[a]), make(agents[b])]
                    sa, sb = 0, 1
                else:
                    seats = [make(agents[b]), make(agents[a]), make(agents[b]), make(agents[a])]
                    sa, sb = 1, 0
                res = play_hand(seats, wall)
                totals[a] += res.scores[sa] + res.scores[sa + 2]
                totals[b] += res.scores[sb] + res.scores[sb + 2]
                hands_played[a] += 1
                hands_played[b] += 1
    table = [Standing(n, totals[n], hands_played[n]) for n in names]
    return sorted(table, key=lambda s: -s.score)
