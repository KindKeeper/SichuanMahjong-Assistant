"""胡牌判定（裁判模块，v1.5 计划口径）。

每个计划各自的目标集合：
- normal：4 组（顺/刻）+ 1 将，两色内
- dazi：4 刻 + 1 将，两色内
- qidui：7 对，两色内，**门清**（有碰杠则不成立）
- flush：单一花色的 normal 型

`melds` = 已碰组数（v1.5 仅碰；杠接入后 4·杠数另计，见 DESIGN §10.2）。
定缺约束：胡牌结构中含缺门花色 ⇒ 不成立。成牌 ⇔ 对应向听 == −1 且张数匹配
（防止 fixed==4 时多余刻子被误判成牌）。重叠牌型 v1 按各计划目标分结算，见 §7-Q5。
"""
from __future__ import annotations

from ..tiles import Counts, Suit
from .shanten import shanten_dazi, shanten_flush, shanten_normal, shanten_qidui


def is_win_any(c: Counts, que: Suit | None, melds: list | tuple) -> bool:
    """计划无关的成牌判定（整局引擎用）：任意基础牌型成立即可。"""
    m = len(melds)
    if que is not None and _has_suit(c, que):
        return False
    if not melds and sum(c) == 14 and shanten_qidui(c) == -1:
        return True
    if not _count_matches(c, m):
        return False
    if shanten_normal(c, fixed_melds=m) == -1 or shanten_dazi(c, fixed_melds=m) == -1:
        return True
    suits = [s for s in range(3) if _has_suit(c, s)]
    return (
        len(suits) == 1
        and all(t // 9 == suits[0] for _, t in melds)
        and shanten_flush(c, suits[0], fixed_melds=m) == -1
    )


def is_tenpai(c: Counts, que: Suit | None = None) -> bool:
    """听牌判定（查叫用）：无缺门牌且四计划最小向听为 0。"""
    if que is not None and _has_suit(c, que):
        return False
    return (
        min(
            shanten_normal(c),
            shanten_qidui(c),
            shanten_dazi(c),
            min(shanten_flush(c, s) for s in range(3)),
        )
        <= 0
    )


def _has_suit(c: Counts, s: Suit) -> bool:
    return any(c[s * 9 : (s + 1) * 9])


def _count_matches(c: Counts, melds: int, pair: bool = True) -> bool:
    need = 3 * (4 - melds) + (2 if pair else 0)
    return sum(c) == need


def is_complete(plan: str, c: Counts, que: Suit | None = None, melds: int = 0) -> bool:
    if que is not None and _has_suit(c, que):
        return False
    if plan == "qidui":
        return melds == 0 and sum(c) == 14 and shanten_qidui(c) == -1
    if plan == "normal":
        return _count_matches(c, melds) and shanten_normal(c, fixed_melds=melds) == -1
    if plan == "dazi":
        return _count_matches(c, melds) and shanten_dazi(c, fixed_melds=melds) == -1
    if plan == "flush":
        suits = [s for s in range(3) if _has_suit(c, s)]
        return (
            len(suits) == 1
            and _count_matches(c, melds)
            and shanten_flush(c, suits[0], fixed_melds=melds) == -1
        )
    raise ValueError(f"unknown plan: {plan}")
