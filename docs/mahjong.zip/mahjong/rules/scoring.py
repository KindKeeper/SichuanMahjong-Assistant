"""和牌算番（裁判模块，T/TFMJ 01—2024 口径，R13/R14）。

计分结构：
- 主体番种（就高不就低，10.4.1a）：清一色4 / 七对4 / 大对子2 / 平和1，按最终组成判定，
  与做牌计划无关（计划只是过程，结算看实际牌型）；
- ×2 加番族：带根（四张相同归一，含未开杠者/杠/暗杠）、金钩钓（单钓将）、
  海底、杠上花、杠上炮、抢杠（后两者哑模型下不可达，接口预留）；
- 支付（10.2.4，首和口径 未和牌人数=3）：自摸 =（底分1 + 基本分）×3；点炮 = 基本分。
- 番种累计 3 番封顶（10.1.1）：语义待确认（R13 开放项），暂未实施——封顶时以"保留分值
  最高的组合"为准，当前对四路线影响极小。

番种计数口径：主体番种计 1，每个 ×2 因子计 1（fan_count 字段备用）。
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from ..tiles import TILES_PER_TYPE, Counts, Suit, Tile
from .shanten import shanten_dazi, shanten_flush, shanten_normal, shanten_qidui
from .yaku import _count_matches, _has_suit

BASE_SCORES = {"flush": 4, "qidui": 4, "dazi": 2, "normal": 1}
MULT_X2 = {"root": "带根", "jingoudiao": "金钩钓", "sea_bottom": "海底", "gang_draw": "杠上花", "gang_discard": "杠上炮", "robbed": "抢杠"}


@dataclass(frozen=True)
class WinScore:
    base_name: str
    base: int
    mults: tuple[str, ...]  # MULT_X2 键，有序

    @property
    def fan_count(self) -> int:
        return 1 + len(self.mults)

    @property
    def total(self) -> int:
        """基本分合计（主体 × 2^加番数）。"""
        return self.base * (2 ** len(self.mults))

    def payment(self, mode: str, n_unwon: int = 3) -> int:
        """10.2.4：自摸 =（底分1 + 基本分）× 未和牌人数；点炮 = 基本分。"""
        if mode == "zimo":
            return (1 + self.total) * n_unwon
        return self.total

    def describe(self) -> str:
        names = [self.base_name] + [MULT_X2[m] for m in self.mults]
        return "+".join(names)


Mel = tuple[str, int]  # 与 simulator.Mel 同构：("peng"|"gang"|"angang", t)


def possession_counts(c: Counts, melds: list[Mel]) -> Counts:
    """最终组成：手牌 + 副露张（带根按"归于一家的全部张数"判定）。"""
    tot = list(c)
    for kind, t in melds:
        tot[t] += 4 if kind in ("gang", "angang") else 3
    return tuple(tot)


def _matched(c: Counts, melds: list[Mel], que: Suit | None) -> dict[str, bool]:
    """各基础番种是否匹配（原始判定，不含组合规则）。"""
    if que is not None and _has_suit(c, que):
        raise ValueError("winning hand contains que-suit tiles")
    fixed = len(melds)
    ok_count = _count_matches(c, fixed)
    suits = [s for s in range(3) if _has_suit(c, s)]
    meld_suits = {t // 9 for _, t in melds}
    flush = (
        len(suits) == 1
        and meld_suits <= set(suits)
        and ok_count
        and shanten_flush(c, suits[0], fixed_melds=fixed) == -1
    )
    return {
        "flush": flush,
        "qidui": not melds and sum(c) == 14 and shanten_qidui(c) == -1,
        "dazi": ok_count and shanten_dazi(c, fixed_melds=fixed) == -1,
        "normal": ok_count and shanten_normal(c, fixed_melds=fixed) == -1,
    }


def score_bases(c: Counts, melds: list[Mel], que: Suit | None) -> tuple[int, str]:
    """official2024 累加口径（10.4：无必然联系的番种组合累加；结构系列内就高）：

    基本分 = 清一色(4，花色维度) + 结构分(七对4/大对子2/平和1 就高)；
    平和为点炮最小分（裸平 1 分）；×2 加番族另计。验证例：清大对=6、清七对=8、
    清一色碰碰胡自摸 = (1+6)×3 = 21（与 10.2.4 一致）。
    """
    m = _matched(c, melds, que)
    if not any(m.values()):
        raise ValueError("not a winning hand")
    if m["qidui"]:
        struct, sname = 4, "qidui"
    elif m["dazi"]:
        struct, sname = 2, "dazi"
    else:
        struct, sname = 1, "normal"  # 平和兜底（最小分）
    total = (4 if m["flush"] else 0) + struct
    return total, ("flush+" if m["flush"] else "") + sname


def detect_base(c: Counts, melds: list[Mel], que: Suit | None) -> tuple[str, int]:
    """v1 存档口径：全部匹配番种就高不就低（单一主体，清大对=4）。对照实验用。"""
    m = _matched(c, melds, que)
    if not any(m.values()):
        raise ValueError("not a winning hand")
    fams = [(n, BASE_SCORES[n]) for n in ("flush", "qidui", "dazi", "normal") if m[n]]
    best = max(s for _, s in fams)
    for n, s in fams:
        if s == best:
            return n, s
    raise AssertionError("unreachable")


def has_root(c: Counts, melds: list[Mel]) -> bool:
    """带根：任一牌最终组成恰为 4 张。"""
    return any(n == TILES_PER_TYPE for n in possession_counts(c, melds))


def _exactly_melds(c: Counts, k: int) -> bool:
    """c 的全部 3k 张能否恰好划分为 k 个面子（顺/刻）。专用判定（跨越 shanten 公式的张数假设）。"""

    @lru_cache(maxsize=None)
    def dfs(t: tuple[int, ...], kk: int) -> bool:
        if kk == 0:
            return all(v == 0 for v in t)
        t = list(t)
        i = 0
        while i < len(t) and t[i] == 0:
            i += 1
        if i == len(t):
            return False
        base = (i // 9) * 9
        r = i - base
        if t[i] >= 3:
            t[i] -= 3
            if dfs(tuple(t), kk - 1):
                return True
            t[i] += 3
        if r + 2 < 9 and t[base + r + 1] and t[base + r + 2]:
            t[i] -= 1
            t[base + r + 1] -= 1
            t[base + r + 2] -= 1
            if dfs(tuple(t), kk - 1):
                return True
        return False

    return dfs(tuple(c), k)


def is_jingoudiao(c: Counts, melds: list[Mel], win_tile: Tile) -> bool:
    """金钩钓：和牌张作将——手牌去掉 2 张和牌张后，恰好剩余 (4−副露) 个完整面子。"""
    if c[win_tile] < 2:
        return False
    c2 = list(c)
    c2[win_tile] -= 2
    return _exactly_melds(tuple(c2), 4 - len(melds))


def _sbr_fans(
    c: Counts,
    melds: list[Mel],
    que: Suit | None,
    win_tile: Tile,
    *,
    gang_draw: bool,
    sea_bottom: bool,
    gang_discard: bool,
    robbed: bool,
) -> tuple[int, str]:
    """SBR 2025（MIL）番数统计：10 种番种，3 番封顶（Q11 的实务答案）。"""
    m = _matched(c, melds, que)
    fans = 0
    parts: list[str] = []
    if m["flush"]:
        fans += 2
        parts.append("清一色")
    if m["qidui"]:
        fans += 2
        parts.append("七对")
    if m["dazi"]:
        fans += 1
        parts.append("大对子")
    if len(melds) == 4 and sum(c) == 1:  # 明牌 4 组刻/杠 + 手牌单吊（SBR 金钩钓定义）
        fans += 1
        parts.append("金钩钓")
    for kind, _ in melds:
        if kind in ("gang", "angang"):
            fans += 1
            parts.append("杠")
    poss = possession_counts(c, melds)
    ganged = {t for kind, t in melds if kind in ("gang", "angang")}
    for t in range(len(poss)):
        if poss[t] == 4 and t not in ganged:
            fans += 1
            parts.append("根")
    if gang_draw:
        fans += 1
        parts.append("杠上花")
    if gang_discard:
        fans += 1
        parts.append("杠上炮")
    if robbed:
        fans += 1
        parts.append("抢杠")
    if sea_bottom:
        fans += 1
        parts.append("海底")
    return fans, "+".join(parts) if parts else "平和"


def score_win(
    c: Counts,
    melds: list[Mel],
    que: Suit | None,
    win_tile: Tile,
    mode: str,
    *,
    gang_draw: bool = False,
    sea_bottom: bool = False,
    gang_discard: bool = False,
    robbed: bool = False,
    profile: str = "official2024",
) -> WinScore:
    """和牌计分。哑模型下 gang_discard/robbed 恒 False（引擎不可达，接口预留）。

    profile="official2024"（默认）：T/TFMJ 累加口径——清一色(4)+结构分(七对4/大对子2/
    平和1 就高)，×2 加番族乘算，自摸=(1+基本分)×人数（用户裁定，见 DESIGN R15）；
    profile="takehighest"：v1 存档口径（全部匹配番种就高取单一主体，清大对=4），对照用；
    profile="sbr2025"：MIL 番数翻番口径——10 种番种各计 1~2 番，基本分=2^min(番数,3)
    （3 番封顶 8 分），自摸每人 基本分+1（与 payment 形状天然一致）。
    """
    if profile == "takehighest":
        name, base = detect_base(c, melds, que)
    elif profile == "sbr2025":
        fans, name = _sbr_fans(
            c, melds, que, win_tile,
            gang_draw=gang_draw, sea_bottom=sea_bottom, gang_discard=gang_discard, robbed=robbed,
        )
        return WinScore(name, 2 ** min(fans, 3), ())
    else:
        base, name = score_bases(c, melds, que)
    mults: list[str] = []
    if has_root(c, melds):
        mults.append("root")
    if is_jingoudiao(c, melds, win_tile):
        mults.append("jingoudiao")
    if gang_draw:
        mults.append("gang_draw")
    if sea_bottom:
        mults.append("sea_bottom")
    if gang_discard:
        mults.append("gang_discard")
    if robbed:
        mults.append("robbed")
    return WinScore(name, base, tuple(mults))
