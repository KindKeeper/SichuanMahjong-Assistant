"""四种牌型的向听数（裁判模块）。

标准型（平胡/清一色）拆牌 DFS，带备忘缓存；键含 target（fixed_melds 变化时必须区分，
zuopai §8-1）。搭子计三面：两面/边张 (i,i+1)、坎张 (i,i+2)、将头已占时的多余对子
——即 zuopai §2.2 的定义（其 §5.1 代码缺后两分支，本项目按定义实现）。

向听约定：13 张听牌 = 0，14 张成牌 = −1。
"""
from __future__ import annotations

from functools import lru_cache

from ..tiles import SUIT_SIZE, Counts, Suit

_TARGET_FULL = 4


def _end_value(meld: int, pair: int, tatsu: int, target: int) -> int:
    return 2 * target - (2 * meld + min(tatsu, target - meld) + pair)


@lru_cache(maxsize=1_000_000)
def _dfs(t: tuple[int, ...], i: int, meld: int, pair: int, tatsu: int, target: int) -> int:
    n = len(t)
    while i < n and t[i] == 0:
        i += 1
    if i == n:
        return _end_value(meld, pair, tatsu, target)

    t = list(t)
    base = 0 if n == SUIT_SIZE else (i // SUIT_SIZE) * SUIT_SIZE
    r = i - base
    in_suit = r + 1 < SUIT_SIZE
    best = 99

    if t[i] >= 3:  # 刻子
        t[i] -= 3
        best = min(best, _dfs(tuple(t), i, meld + 1, pair, tatsu, target))
        t[i] += 3

    if r + 2 < SUIT_SIZE and t[base + r + 1] and t[base + r + 2]:  # 顺子（不跨花色）
        t[i] -= 1
        t[base + r + 1] -= 1
        t[base + r + 2] -= 1
        best = min(best, _dfs(tuple(t), i, meld + 1, pair, tatsu, target))
        t[i] += 1
        t[base + r + 1] += 1
        t[base + r + 2] += 1

    if t[i] >= 2:
        t[i] -= 2
        if not pair:  # 将
            best = min(best, _dfs(tuple(t), i, meld, 1, tatsu, target))
        else:  # 将头已占：多余对子作搭子
            best = min(best, _dfs(tuple(t), i, meld, pair, tatsu + 1, target))
        t[i] += 2

    if in_suit and t[base + r + 1]:  # 两面/边张搭子
        t[i] -= 1
        t[base + r + 1] -= 1
        best = min(best, _dfs(tuple(t), i, meld, pair, tatsu + 1, target))
        t[i] += 1
        t[base + r + 1] += 1

    if r + 2 < SUIT_SIZE and t[base + r + 2]:  # 坎张搭子
        t[i] -= 1
        t[base + r + 2] -= 1
        best = min(best, _dfs(tuple(t), i, meld, pair, tatsu + 1, target))
        t[i] += 1
        t[base + r + 2] += 1

    t[i] -= 1  # 孤张
    best = min(best, _dfs(tuple(t), i, meld, pair, tatsu, target))
    t[i] += 1
    return best


def shanten_normal(c: Counts, fixed_melds: int = 0) -> int:
    """平胡向听：4 组（顺/刻）+ 1 将。"""
    return _dfs(tuple(c), 0, 0, 0, 0, _TARGET_FULL - fixed_melds)


def shanten_flush(c: Counts, suit: Suit, fixed_melds: int = 0) -> int:
    """清一色向听：单花色段内的平胡向听（其余花色视为不存在）。"""
    seg = tuple(c[suit * SUIT_SIZE : (suit + 1) * SUIT_SIZE]) + (0,) * (len(c) - SUIT_SIZE)
    return _dfs(seg, 0, 0, 0, 0, _TARGET_FULL - fixed_melds)


def shanten_qidui(c: Counts) -> int:
    """七对向听：6 − 对子数（每种牌 count≥2 算一对，四张只算一对，龙七对见 §7-Q1）。"""
    return 6 - sum(1 for v in c if v >= 2)


def shanten_dazi(c: Counts, fixed_melds: int = 0) -> int:
    """大对子向听：2·(4−fixed) − 2·刻子数 − 是否有对子（将）。各牌种独立贪心最优。"""
    t = 0
    has_pair = False
    for v in c:
        t += v // 3
        if v % 3 == 2:
            has_pair = True
    return 2 * (4 - fixed_melds) - 2 * t - (1 if has_pair else 0)
