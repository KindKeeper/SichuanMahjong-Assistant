"""沙箱 Agent（T2，§12.4 防作弊 ①）：把任意 Agent 类装进子进程隔离执行。

引擎只通过 JSON 消息与子进程交互；子进程内的策略物理上无法 inspect 引擎内存
（威胁模型实证：tests/test_cheating_canary.py）。

用法：
    agent = SandboxedAgent("mahjong.agents.seat_agents:GreedyAgent", plan='"normal"')
    # 实现 Agent 协议，可与其他进程内 Agent 同场 play_hand
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import asdict

import mahjong

from .agents.base import Ctx


def _env_with_src() -> dict:
    env = dict(os.environ)
    src = os.path.dirname(os.path.dirname(mahjong.__file__))
    env["PYTHONPATH"] = src + os.pathsep + env.get("PYTHONPATH", "")
    return env


class SandboxedAgent:
    """子进程隔离的 Agent 包装（惰性启动，close() 回收）。"""

    def __init__(self, target: str, **kwargs):
        self.target = target
        self.kwargs = kwargs
        self._proc: subprocess.Popen | None = None

    def _ensure(self) -> subprocess.Popen:
        if self._proc is None:
            argv = [sys.executable, "-m", "mahjong.agent_host", self.target]
            for k, v in self.kwargs.items():
                argv.append(f"{k}={json.dumps(v)}")
            self._proc = subprocess.Popen(
                argv,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                env=_env_with_src(),
            )
        return self._proc

    def _call(self, method: str, hand, ctx: Ctx, tile=None):
        proc = self._ensure()
        req = {"method": method, "hand": list(hand), "ctx": asdict(ctx), "tile": tile}
        proc.stdin.write(json.dumps(req) + "\n")
        proc.stdin.flush()
        line = proc.stdout.readline()
        if not line:
            raise RuntimeError("agent_host subprocess died")
        return json.loads(line)["result"]

    def close(self) -> None:
        if self._proc is not None:
            self._proc.terminate()
            self._proc.wait(timeout=5)
            self._proc = None

    # --- Agent 协议（全部转发子进程） ---
    def choose_que(self, hand, ctx):
        return self._call("choose_que", hand, ctx)

    def choose_discard(self, hand, ctx):
        return self._call("choose_discard", hand, ctx)

    def should_zimo(self, hand, ctx):
        return bool(self._call("should_zimo", hand, ctx))

    def should_rong(self, hand, tile, ctx):
        return bool(self._call("should_rong", hand, ctx, tile))

    def should_peng(self, hand, tile, ctx):
        return bool(self._call("should_peng", hand, ctx, tile))

    def should_daming_gang(self, hand, tile, ctx):
        return bool(self._call("should_daming_gang", hand, ctx, tile))

    def should_angang(self, hand, tile, ctx):
        return bool(self._call("should_angang", hand, ctx, tile))

    def should_jiagang(self, hand, tile, ctx):
        return bool(self._call("should_jiagang", hand, ctx, tile))

    def should_qiang_gang(self, hand, tile, ctx):
        return bool(self._call("should_qiang_gang", hand, ctx, tile))
