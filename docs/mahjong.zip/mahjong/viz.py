"""终端可视化（零依赖）：横向条形图 + 字符热力图。

实验报告用；不引入 matplotlib 以保持纯 stdlib 基调。
"""
from __future__ import annotations

BAR = "█"


def hbar(title: str, items: list[tuple[str, float]], width: int = 40, fmt: str = "{:.2f}") -> str:
    """items: [(标签, 值)]；按最大绝对值归一画横向条形。"""
    lines = [f"### {title}", ""]
    if not items:
        return title + "\n(空)"
    vmax = max(abs(v) for _, v in items) or 1.0
    label_w = max(len(k) for k, _ in items)
    for label, v in items:
        n = max(1, int(abs(v) / vmax * width)) if v else 0
        bar = BAR * n
        sign = "+" if v > 0 else ""
        lines.append(f"{label:<{label_w}} │{bar:<{width}} {sign}{fmt.format(v)}")
    return "\n".join(lines)


def grouped_hbar(
    title: str,
    groups: list[str],
    series: list[tuple[str, list[float], str]],
    width: int = 36,
    fmt: str = "{:.2f}",
) -> str:
    """分组条形：series = [(系列名, [每组值], 图例字符)]。每组下多行（每系列一行）。"""
    lines = [f"### {title}", ""]
    flat = [v for _, vals, _ in series for v in vals]
    vmax = max(abs(v) for v in flat) or 1.0
    group_w = max(len(g) for g in groups)
    name_w = max(len(n) for n, _, _ in series)
    for g_i, g in enumerate(groups):
        lines.append(f"{g:>{group_w}}")
        for name, vals, ch in series:
            v = vals[g_i]
            n = max(1, int(abs(v) / vmax * width)) if v else 0
            sign = "+" if v > 0 else ""
            lines.append(f"  {name:<{name_w}} │{ch * n:<{width}} {sign}{fmt.format(v)}")
    return "\n".join(lines)


def heatmap(
    title: str,
    row_labels: list[str],
    col_labels: list[str],
    cells: list[list[str]],
) -> str:
    """字符热力图：cells[i][j] = 单字符标记（如推荐计划字母）。"""
    lines = [f"### {title}", ""]
    col_w = max(len(c) for c in col_labels) + 1
    corner = " " * (max(len(r) for r in row_labels) + 2)
    lines.append(corner + "".join(f"{c:^{col_w}}" for c in col_labels))
    for r, row in zip(row_labels, cells):
        lines.append(f"{r:>{len(corner)-2}} │ " + " ".join(f"{cell:^{col_w-1}}" for cell in row))
    return "\n".join(lines)
